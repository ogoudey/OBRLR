# pylint: disable=E0402
from .KException import KException 
from ..autogen.messages import Frame_pb2 as FramePb
from ..autogen.messages import Errors_pb2 as ErrorsPb
from ..internal import BitMaskTools

class KServerException(KException):
    """Exception thrown by servers when something goes wrong on their side.

    These exceptions originate on the Server side and are thrown by the Client when it receives the Exception.
    """

    def __init__(self, frame):
        self.frame = frame

        # Extract codes from the header, always
        self.error_code = BitMaskTools.extractErrorCode(frame.header.frame_info)
        self.error_sub_code = BitMaskTools.extractErrorSubCode(frame.header.frame_info)
        self.error_sub_string = str()

        # Extract description if present
        error_to_parse = FramePb.Error()
        try:
            error_to_parse.ParseFromString(frame.payload)
        except:
            self.error_sub_string = "Error details were not received from server."
        else:
            self.error_sub_string = error_to_parse.error_sub_string
        super().__init__(self.error_sub_string)

        # This error existed as a member of this class so we won't remove it, we fill it instead
        self.error = FramePb.Error()
        self.error.error_code = self.error_code
        self.error.error_sub_code = self.error_sub_code
        self.error.error_sub_string = self.error_sub_string

    def __str__(self):
        code_name = ErrorsPb.ErrorCodes.Name(self.error_code)
        sub_code_name = ErrorsPb.SubErrorCodes.Name(self.error_sub_code)
        return 'Server error name={0}, sub name={1} => {2} \n'.format(code_name, sub_code_name, self.error_sub_string)

    
    def get_error_code(self):
        """Returns the error code associated to the exception.
        
        Returns:
            :class:`~kortex_api.autogen.ErrorCodes`: The error code.
        """
        return self.error_code

    
    def get_error_sub_code(self):
        """Returns the sub error code associated to the exception.

        Returns:
            :class:`~kortex_api.autogen.SubErrorCodes` The sub error code.
        """
        return self.error_sub_code
