class KException(Exception):
    """Base class for Kinova Exceptions.
    """
    def __init__(self, description):
        self.description = description
        super().__init__(self.description)

    def __str__(self):
        return 'Error encountered : {0}'.format(self.description)
