"""This module imports the Kortex MQTT Transport, which permits high-level communication with Link arms. 
"""
import paho.mqtt.client as mqtt
from paho.mqtt.properties import Properties
from paho.mqtt.packettypes import PacketTypes 

import logging
import threading

from .autogen.messages import Frame_pb2 as FramePb  # NOQA
from .Constants import DEFAULT_MQTT_BROKER_PORT, DEFAULT_MQTT_TIMEOUT_SEC
from .internal.NotificationHandler import _NotificationKey
from .internal import BitMaskTools
from .ITransportClient import ITransportClient


class MqttTransport(ITransportClient):
    """Kortex Transport which communicates with Kortex devices over MQTT (high level API).
    
    The normal usage is to create the transport, then pass it to the :class:`~kortex_api.RouterClient` as it 
    is created, then connect the transport to the Kortex device by calling the :meth:`connect` method.
    When the program reaches its end, you can call :meth:`disconnect` or simply let the destructor run, 
    as it cleanly disconnects the transport itself.

    **Usage :**
    ::
    
        transport = MqttTransport()
        
        router = RouterClient(transport)
        
        transport.connect("192.168.1.10", 1883)
        
        # Body of the code
        ...

        transport.disconnect() # optional
    """
    
    MQTT_MAX_PAYLOAD_SIZE = 268435455
    
    def __init__(self, enable_logger = False):
        """Constructor for an MqttTransport.

        No connection information is passed to this method, as the connection only happens on a call to the "connect" method.

        Args:
            enable_logger (bool, optional): If True, enables DEBUG logging level in the transport. Defaults to False.
        """

        self.maxTxBufferSize = self.MQTT_MAX_PAYLOAD_SIZE
        
        self.client = mqtt.Client(protocol=mqtt.MQTTv5)
        self.connection_code = None
        self.connect_condition = threading.Condition()
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        
        self.client.on_message = self._on_message

        logger = logging.getLogger(__name__)
        self.client.enable_logger(logger)

        # Create logger for exceptions and errors
        FORMAT = '%(asctime)s %(message)s'

        # If logger is enabled, all messages will be printed, otherwise only errors
        # Levels available: Debug -> Info -> Warning -> Error -> Critical
        if enable_logger:
            logging.basicConfig(format=FORMAT, level=logging.DEBUG)
        else:
            logging.basicConfig(format=FORMAT, level=logging.WARNING)

        self.rawCallbacks = {}


    def __del__(self):
        """Automatically disconnects upon destruction.
        """
        self.disconnect()

    def _isNamespaceSupported(self):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        return True

    # return True if client is connected to MQTT Broker and received CONNACK_ACCEPTED
    def _is_connection_accepted(self):
        return self.connection_code == mqtt.CONNACK_ACCEPTED


    def connect(self, host: str, port: int = DEFAULT_MQTT_BROKER_PORT, timeoutSeconds: int = DEFAULT_MQTT_TIMEOUT_SEC):
        """See :class:`~kortex_api.ITransportClient` base class for description.

        Connects to a Kortex device through MQTT. An optional timeout can be specified to raise a ConnectionError if
        the connection is not established after a given period of time.

        Args:
            host (str): Address of the Kortex device to connect to.
            port (int, optional): Port of the Kortex device to connect to. Defaults to DEFAULT_MQTT_BROKER_PORT.
            timeoutSeconds (int, optional): Timeout for the connection, in seconds. Defaults to DEFAULT_MQTT_TIMEOUT_SEC.

        Raises:
            ConnectionError: The transport could not connect to the Kortex device within the 'timeoutSeconds' duration.
        """

        self.client.connect(host, port)
        self.client.loop_start()

        # Wait until CONNACK_ACCEPTED is received or timeout occurs
        with self.connect_condition:

            # Wait until connected            
            if not self.connect_condition.wait_for(self._is_connection_accepted, timeoutSeconds):

                if self.connection_code is None:
                    raise ConnectionError("Connection Timeout")
                else:
                    raise ConnectionError(mqtt.connack_string(self.connection_code))
            

    def disconnect(self):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        # Does nothing if not connected or loop not started
        self.client.disconnect()
        self.client.loop_stop()



    def _send(self, payload: str, header: FramePb.Header, namespace: str):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """

        topic = MqttTransport._generate_topic(header, namespace)


        frameType = BitMaskTools.extractFrameType(header.frame_info)

        publish_properties = None
        if frameType == FramePb.MSG_FRAME_REQUEST:

            publish_properties = Properties(PacketTypes.PUBLISH)
            publish_properties.ResponseTopic = self.responseTopic

            # Each request has a unique correlation data
            frameId = BitMaskTools.extractFrameId(header.message_info)

            publish_properties.CorrelationData = frameId.to_bytes(2, 'big')


        self.client.publish(topic, payload, qos=0, properties=publish_properties)


    def getMaxTxBufferSize(self) -> int:
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        return self.maxTxBufferSize


    def _registerOnFrameCallback(self, callback):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self.onFrameCallback = callback

    def _registerRawCallback(self, callback, topic: str):
        """Internal method : register a callback for when a raw message on a certain topic is received.

        Args:
            callback (function): Callback to execute.
            topic (str): Topic on which to listen.
        """
        self.rawCallbacks[topic] = callback
    
    def _unregisterRawCallback(self, topic: str):
        """Internal method : unregister a raw callback.

        Args:
            topic (str): Topic on which to stop listening.
        """
        if topic in self.rawCallbacks:
            del self.rawCallbacks[topic]

    def _subscribe(self, notifId: _NotificationKey):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._subscribeToTopic(MqttTransport._generate_notif_topic(notifId._namespace, notifId._serviceId, notifId._functionId))

    def _unsubscribe(self, notifId: _NotificationKey):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._unsubscribeFromTopic(MqttTransport._generate_notif_topic(notifId._namespace, notifId._serviceId, notifId._functionId))

    def _subscribeToSessionPing(self, sessionId: int):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._subscribeToTopic(MqttTransport._generate_ping_topic(sessionId))

    def _unsubscribeFromSessionPing(self, sessionId: int):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._unsubscribeFromTopic(MqttTransport._generate_ping_topic(sessionId))

    def _subscribeToTopic(self, topic: str):
        """Internal method : subscribe to an MQTT topic.

        Args:
            topic (str): Topic on which to listen.
        """
        self.client.subscribe(topic)

    def _unsubscribeFromTopic(self, topic: str):
        """Internal method : unsubscribe from an MQTT topic.

        Args:
            topic (str): Topic on which to stop listening.
        """
        self.client.unsubscribe(topic)

    def _on_connect(self, client: mqtt.Client, userdata, flags, reasonCode, properties):
        """Internal method : called when the client receives a CONNACK response from the broker.
        """

        with self.connect_condition:
            self.connection_code = reasonCode
            self.connect_condition.notify()

            if self._is_connection_accepted():
                
                # broker sets a unique identifier to the client
                logging.info("MQTT client connected with assigned Identifier: " + str(properties.AssignedClientIdentifier))

                # Set unique response topic and subscribe to it
                self.responseTopic = "res/" + properties.AssignedClientIdentifier
                client.subscribe(self.responseTopic)

                # TODO On reconnect, we should resubscribe to all previous topics when clean_session is False.  
                # Subscribing in on_connect() means that if we lose the connection and
                # reconnect, then subscriptions will be renewed.

            else:
                logging.error("Unable to connect: " + mqtt.connack_string(reasonCode))


    def _on_disconnect(self, client: mqtt.Client, userdata, rc, properties): 
        """Internal method : called when the client disconnects from the broker.
        """

        logging.info("MQTT client disconnected")

        with self.connect_condition:
            self.connection_code = None
            self.connect_condition.notify()

        # The rc parameter indicates the disconnection state. 
        # If MQTT_ERR_SUCCESS(0), the callback was called in response to a disconnect() call. 
        if rc != mqtt.MQTT_ERR_SUCCESS:
            logging.error("Unexpected disconnect: " + mqtt.error_string(rc))

    def _generate_notif_topic(namespace, serviceId, functionId):
        topic = namespace + "/" if (namespace != None and len(namespace) > 0) else ""
        topic += "notif/" + str(serviceId) + "/" + str(functionId)
        return topic

    def _generate_ping_topic(sessionId):
        return "ping/" + str(sessionId)

    # Generate topic depending of frame type and namespace 
    def _generate_topic(header: FramePb.Header, namespace):

        frameType = BitMaskTools.extractFrameType(header.frame_info)
        
        topic = namespace + "/" if (namespace != None and len(namespace) > 0) else ""

        if frameType == FramePb.MSG_FRAME_REQUEST:
            
            deviceId = BitMaskTools.extractDeviceId(header.frame_info)
            serviceId = BitMaskTools.extractServiceId(header.service_info)
            functionId = BitMaskTools.extractFunctionId(header.service_info)

            topic += "dev/" + str(deviceId) if deviceId > 0 else "req/" 
            topic += str(serviceId) + "/" + str(functionId)
        
        elif frameType == FramePb.MSG_FRAME_NOTIFICATION:

            serviceId = BitMaskTools.extractServiceId(header.service_info)
            functionId = BitMaskTools.extractFunctionId(header.service_info)

            return MqttTransport._generate_notif_topic(namespace, serviceId, functionId)

        elif frameType == FramePb.MSG_FRAME_PING:

            sessionId = BitMaskTools.extractSessionId(header.message_info)    
            return MqttTransport._generate_ping_topic(sessionId)

        elif frameType == FramePb.MSG_FRAME_PONG:

            sessionId = BitMaskTools.extractSessionId(header.message_info)    
            return "pong/" + str(sessionId)

        # Support other frame types when needed 
        else:
            raise ValueError("Unsupported frame type for current Python MQTT Transport implementation")

        return topic 

    def _on_message(self, client:mqtt.Client, userdata, msg):
        """Internal method : called when the client receives a new message.
        """

        # Check for raw callbacks first
        if msg.topic in self.rawCallbacks:
            try:
                self.rawCallbacks[msg.topic](msg.payload)
            except Exception as e:
                logging.error(f"Exception happened during raw callback for topic {msg.topic} with error message : {str(e)}")

        elif self.onFrameCallback:

            # Retrieve namespace from topic if any: "<namespace>/notif/..." 
            namespace = None
            namespaceEnd = msg.topic.find("/notif/")
            if namespaceEnd > 0:
                namespace = msg.topic[0:namespaceEnd]

            self.onFrameCallback(msg.payload, namespace)
