"""This module imports the Kortex UDP Transport, which permits low-level communication with Link arms. 
"""
import inspect
import select
import socket
import sys
import threading

from .Constants import DEFAULT_UDP_PORT
from .ITransportClient import ITransportClient
from .exceptions.KException import KException
from .internal.NotificationHandler import _NotificationKey

class UDPTransport(ITransportClient):
    """Kortex Transport which communicates with Kortex devices over UDP (low-level API).
    
    The normal usage is to create the transport, then pass it to the :class:`~kortex_api.RouterClient` as it is created,
    then connect the transport to the Kortex device. When the program reaches its end, you have to call "disconnect".

    **Usage :**
    ::
    
        transport = UDPTransport()

        router = RouterClient(transport)
        
        transport.connect("192.168.1.10")
        
        # Body of the code
        ...

        transport.disconnect()
    """

    def __init__(self):
        """Constructor for a UDPTransport.

        No connection information is passed to this method, as the connection only happens on a call to the connect() method.
        """
        self._address = ('', 0)
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udpTransportThread = _UDPTransportThread()
        self._udpTransportThread.daemon = True
        self._event = threading.Event()

        # 65535 - 20 (ip header) - 8 (udp header) = 65507 bytes
        self.maxTxBufferSize = 65507

        self._sock.setblocking(0)
        super().__init__()

    def __del__(self):
        self._event.set()
        if self._udpTransportThread.is_alive():
            self._udpTransportThread.join(timeout=2)

    def _isNamespaceSupported(self):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        return False

    def connect(self, ip: str, port: int = DEFAULT_UDP_PORT):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._address = (ip, port)
        try:
            self._sock.connect(self._address)
            self._udpTransportThread._setup(sock=self._sock, event=self._event)
            self._udpTransportThread.start()
        except OSError as ex:
            self._sock.close()
            print("[{}.{}] ERROR: {}".format(self.__class__.__name__, inspect.stack()[0][3], ex.strerror), file=sys.stderr, flush=True)
            raise ex

    def disconnect(self):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        self._event.set()
        self._udpTransportThread.join()
        self._sock.close()

    def _send(self, payload: str, header = None, namespace = None):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        try:
            # Send data from payload until either all data has been sent or an error occurs.
            self._sock.sendall(payload)

        except Exception as ex:
            print("[{}.{}] ERROR: {}".format(self.__class__.__name__, inspect.stack()[0][3], ex.strerror), file=sys.stderr, flush=True)
            raise ex

    def getMaxTxBufferSize(self):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        return self.maxTxBufferSize

    def _registerOnFrameCallback(self, callback):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        if callback is None:
            raise KException("Frame callback registration error: callback is null")
        self._udpTransportThread._set_frame_callback(callback)

    def _subscribe(self, notifId: _NotificationKey):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        pass

    def _unsubscribe(self, notifId: _NotificationKey):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        pass

    def _subscribeToSessionPing(self, sessionId: int):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        pass

    def _unsubscribeFromSessionPing(self, sessionId: int):
        """See :class:`~kortex_api.ITransportClient` base class for description.
        """
        pass

class _UDPTransportThread(threading.Thread):
    def __init__(self):
        self._sock = None
        self._event = None
        self._onFrameCallback = None
        super().__init__()

    def _setup(self, sock, event):
        self._sock = sock
        self._event = event

    def _set_frame_callback(self, cb):
        self._onFrameCallback = cb

    def run(self):
        while not self._event.is_set():
            try:
                # SELECT with a 500 ms timeout
                readable, writable, exceptional = select.select([self._sock], [], [], 0.5)
                
                # If the socket is not ready to be read, we continue to the next loop cycle.
                if (readable or writable or exceptional):
                    if self._onFrameCallback:
                        try:
                            # 65535 - 20 (ip header) - 8 (udp header) = 65507 bytes
                            data = self._sock.recv(65507)
                        
                        except Exception as exception:
                            print("recv() failed with {}".format(exception))
                            
                            continue    # abort current receive loop iteration
            
                        self._onFrameCallback(data)

            except IOError as e:
                # Error occurred in SELECT
                print("select() failed with {}".format(e))
