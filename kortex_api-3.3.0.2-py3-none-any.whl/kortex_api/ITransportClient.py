    
"""This module contains the interface for any Kortex API Transport which the RouterClient takes in argument to function properly.
"""

from abc import ABC, abstractmethod
from .internal.NotificationHandler import _NotificationKey

class ITransportClient(ABC):
    """Abstract interface that all Kortex API Transports have to reimplement.
    """
    def __init__(self):
        pass

    @abstractmethod
    def connect(self, host: str, port: int):
        """Attempts to connect the transport to the Kortex device. 

        Args:
            host (str): Address of the Kortex device to connect to.
            port (int): Port of the Kortex device to connect to.
        """
        pass

    @abstractmethod
    def disconnect(self):
        """Attempts to disconnect the transport from the Kortex device it is connected to.

        Does nothing if the transport is not connected.
        """
        pass

    @abstractmethod
    def _send(self, payload: str, header: str, namespace: str = None):
        """Internal method : sends a payload to the connected Kortex device.

        Args:
            payload (str): Payload to send.
            header (str): Header of the frame.
            namespace (str, optional): Namespace on which to send the payload. Defaults to None.
        """
        pass

    @abstractmethod
    def getMaxTxBufferSize(self) -> int:
        """Gets the maximum transfer buffer size, in bytes.
        """
        pass

    @abstractmethod
    def _registerOnFrameCallback(self, callback):
        """Internal method : Registers the callback for when a Frame is received.

        Args:
            callback (function): Callback to register.
        """
        pass

    @abstractmethod
    def _isNamespaceSupported(self) -> bool:
        """Returns true if namespacing is supported by this Kortex transport subclass.
        """
        pass

    @abstractmethod
    def _subscribe(self, notifId:_NotificationKey):
        """Internal method : subscribes to a certain notification key,
        """
        pass

    @abstractmethod
    def _unsubscribe(self, notifId:_NotificationKey):
        """Internal method : unsubscribes from a certain notification key,
        """
        pass

    @abstractmethod
    def _subscribeToSessionPing(self, sessionId: int):
        """Internal method : subscribes to a ping topic with a given session ID.
        """
        pass

    @abstractmethod
    def _unsubscribeFromSessionPing(self, sessionId: int):
        """Internal method : unsubscribes from a ping topic with a given session ID.
        """
        pass