"""This module imports the Kortex Router, which is in turn used to instantiate service clients for Kortex API RPC calls. 
"""
from concurrent.futures import Future
from functools import partial
import sys
import threading

from google.protobuf.message import DecodeError

from .autogen.messages import Errors_pb2 as ErrorsPb  # NOQA
from .autogen.messages import Frame_pb2 as FramePb  # NOQA
from .exceptions.KClientException import KClientException
from .Constants import DEFAULT_CONTROLLER_ADDRESS, DEFAULT_MQTT_BROKER_PORT
from .internal import BitMaskTools
from .internal.FrameHandler import _FrameHandler
from .internal.NotificationHandler import _NotificationHandler, _NotificationKey
from .ITransportClient import ITransportClient
from .MqttTransport import MqttTransport

class RouterClientSendOptions:
    """Options for when a message is sent with the Router.

    The only supported option for now is a timeout duration, in milliseconds.
    """
    def __init__(self):
        self.timeout_ms = 10000

    def getTimeoutInSecond(self) -> float:
        return self.timeout_ms / 1000


class RouterClient:
    """Leverages a Kortex Transport to properly route inbound and outbound Kortex frames to and from the proper Kortex Services.

    Creating a RouterClient is necessary in order to issue RPC calls to a Kortex device. It needs to be supplied a valid :class:`~kortex_api.ITransportClient`
    at construction, and then Kortex Service Clients (see kortex_api.autogen.client_stubs) can be created using the RouterClient.

    If no transport is provided to the constructor, it will create a :class:`~kortex_api.MqttTransport` and try to connect it to a Kortex device.

    Before disconnecting the transport, :meth:`SetActivationStatus` must be called to cleanly destroy the RouterClient.

    **Usage :**
    ::
    
        from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient

        transport = MqttTransport()

        router = RouterClient(transport)

        transport.connect("192.168.1.10")

        # The router can be used to create a Service Client as such :

        base_client = BaseClient(router)

        # The Service Client can then be used to call RPCs and subscribe to notifications

        router.SetActivationStatus(False)

        transport.disconnect()
    """

    def __init__(self, transport: ITransportClient = None, errorCallback = None, mqttBrokerHost: str = DEFAULT_CONTROLLER_ADDRESS, mqttBrokerPort: int = DEFAULT_MQTT_BROKER_PORT):
        """Constructor for the RouterClient.

        Passing it no argument will make it create a :class:`~kortex_api.MqttTransport` on its own, and try to connect it to a Kortex device.
        If a transport is supplied, it must be connected after the construction of the RouterClient for it to work properly.

        Args:
            transport (:class:`~kortex_api.ITransportClient`, optional): Kortex Transport this Router will use. Defaults to None.
            errorCallback (function, optional): Custom error callback to call when something goes awry. Defaults to None.
            mqttBrokerHost (str, optional): If no transport is provided, this address will be used to connect the default transport. Defaults to DEFAULT_CONTROLLER_ADDRESS.
            mqttBrokerPort (int, optional): If no transport is provided, this port will be used to connect the default transport. Defaults to DEFAULT_MQTT_BROKER_PORT.
        """
        if transport:
            self._transport = transport
        else:
            self._transport = MqttTransport()
            self._transport.connect(mqttBrokerHost, mqttBrokerPort)

        self._notificationHandler = _NotificationHandler()
        self._sessionId = 0
        self._isActive = True
        self._transport._registerOnFrameCallback(partial(self._onFrameCallback))
        self._errorCallback = errorCallback
        self._frameHandler = _FrameHandler()
        self._hitCallback = None

        # If no error callback is provided, default is the basic one
        if self._errorCallback is None:
            def basicErrorCallback(kException):
                print("[{}] {}".format(self.__class__.__name__, kException), file=sys.stderr)
            self._errorCallback = basicErrorCallback

    def SetActivationStatus(self, isActive: bool):
        """Sets the activation status of the RouterClient.

        Needs to be called before disconnecting the transport. 

        Args:
            isActive (bool): Activation status.
        """
        self._isActive = isActive

    def _isAlive(self, serviceId: int, ns: str, timeoutMs: int) -> bool:
        """Internal method : ping a given service server to know if it's alive.

        Args:
            serviceId (int): Service ID to ping.
            ns (str): Optional namespace of the service server.
            timeoutMs (int): Timeout to wait for an answer, in milliseconds.

        Raises:
            RuntimeError: The router's transport does not support this method.

        Returns:
            bool: True if the service is alive, False otherwise.
        """

        if isinstance(self._transport, MqttTransport):
            server_is_alive = threading.Condition()
            ns_to_append = "/" + ns if ns else ""
            pingTopic = "services/ping/" + str(serviceId) + ns_to_append
            pongTopic = "services/pong/" + str(serviceId) + ns_to_append

            def onMessageIsAlive(payload):
                nonlocal server_is_alive
                with server_is_alive:
                    server_is_alive.notify()
            
            self._transport._registerRawCallback(onMessageIsAlive, pongTopic) # Register a callback for the topic
            self._transport._subscribeToTopic(pongTopic)                      # Subscribe to the topic
            self._transport.client.publish(pingTopic, "") # Publish to the topic for server to respond
            with server_is_alive:
                success = server_is_alive.wait(timeoutMs/1000)
        else:
            raise RuntimeError("_isAlive can only be used with MQTT communication!")

        # Unregister callback and unsubscribe to topic
        self._transport._unsubscribeFromTopic(pongTopic)
        self._transport._unregisterRawCallback(pongTopic)
                
        return success
    
    def _send(self, payloadData, serviceVersion, functionUid, deviceId, namespace = None, options: RouterClientSendOptions = None):
        """Internal method : send a Kortex Frame through the transport.
        """
        if not self._isActive:
            future = Future()
            future.set_exception(KClientException(ErrorsPb.ERROR_PROTOCOL_CLIENT, "Activation Status set to False"))
            return future
      
        msgFrame, msgFrameId, future = self._frameHandler.createRequestFrame(payloadData, serviceVersion, functionUid, deviceId, self._sessionId)

        maxSize = self._transport.getMaxTxBufferSize()
        
        payload = msgFrame.SerializeToString()

        if maxSize and len(payload) > maxSize:
            clientException = KClientException( ErrorsPb.TOO_LARGE_ENCODED_FRAME_BUFFER,
                                                "Serialized message data is bigger than maximum acceptable size: size={0} > max={1}" 
                                                .format(len(payload), self._transport.maxTxBufferSize))
            self._frameHandler.forcePromiseException(payload, clientException)
        
        else:

            try:
                self._transport._send(payload, msgFrame.header, namespace)

                if self._hitCallback is not None:
                    self._hitCallback(FramePb.MSG_FRAME_REQUEST)
            
            except Exception as e:
                clientException = KClientException(ErrorsPb.ERROR_PROTOCOL_CLIENT, "Couldn't send message frame : {}".format(str(e)))
                self._frameHandler.forcePromiseException(msgFrameId, clientException)
                raise

        return future

    def GetConnectionId(self) -> int:
        """Returns the router's session ID.

        If the router does not have a valid session, 0 is returned.
        """
        return self._sessionId


    def _onFrameCallback(self, payload: str, namespace: str = None):
        """Internal callback method : called when the transport has a new message.
        """
        if self._isActive:
            frame = FramePb.Frame()
            clientException = None

            try:

                frame.ParseFromString(payload)

                frameType = BitMaskTools.extractFrameType(frame.header.frame_info)
                header = frame.header

                if (frameType == FramePb.MSG_FRAME_RESPONSE):
                    
                    if self._hitCallback is not None:
                        self._hitCallback(frameType)

                    sessionId = BitMaskTools.extractSessionId(header.message_info)
                    
                    # Update client's sessionId if it changed
                    if sessionId != self._sessionId:

                        if self._sessionId != 0:
                            self._transport._unsubscribeFromSessionPing(self._sessionId)
                            
                        self._sessionId = sessionId 
                        
                        if self._sessionId != 0:
                            self._transport._subscribeToSessionPing(self._sessionId)

                    errStatus = self._frameHandler.manageResponseFrame(frame)

                    if (errStatus.error_code != ErrorsPb.ERROR_NONE):
                        clientException = KClientException.createFromError(errStatus)

                elif (frameType == FramePb.MSG_FRAME_NOTIFICATION):

                    serviceId = BitMaskTools.extractServiceId(header.service_info)
                    functionId = BitMaskTools.extractFunctionId(header.service_info)
                    notifId = _NotificationKey(namespace, serviceId, functionId)
                    self._notificationHandler.notifyCallbacks(notifId, frame.payload)

                elif (frameType == FramePb.MSG_FRAME_PING):
                    
                    # send back pong
                    frame.header.frame_info = BitMaskTools.changeFrameType(FramePb.MSG_FRAME_PONG, frame.header.frame_info)
                    frame.header.message_info = BitMaskTools.changeSessionId(self._sessionId, frame.header.message_info)
                    self._transport._send(frame.SerializeToString(), frame.header, namespace)

                else:
                    # Notify error
                    clientException = KClientException(ErrorsPb.UNSUPPORTED_FRAME_TYPE,
                                                    "Unrecognized frame type received {0}"
                                                    .format(frameType))
                                                    
            except DecodeError:
                clientException = KClientException(ErrorsPb.FRAME_DECODING_ERR, "Couldn't decode message frame")

            if clientException and self._errorCallback is not None:
                self._errorCallback(clientException)

    def _registerNotificationCallback(self, functionUid, namespace, notifCallback):
        """Internal method : service clients register notification callbacks.
        """

        serviceId = BitMaskTools.extractServiceId(functionUid.value)
        functionId = BitMaskTools.extractFunctionId(functionUid.value)
        notifId = _NotificationKey(namespace, serviceId, functionId)
        
        self._notificationHandler.addCallback(notifId, notifCallback)

        self._transport._subscribe(notifId)

    def _unregisterNotificationCallback(self, callbackId, namespace):
        """Internal method : service clients unregister notification callbacks.
        """

        notifId = self._notificationHandler.getNotifIdentifier(namespace, callbackId)
        remaining_count = self._notificationHandler.deleteCallback(notifId, callbackId)

        if remaining_count == 0:
            self._transport._unsubscribe(notifId)

    def _registerHitCallback(self, cb):
        self._hitCallback = cb
