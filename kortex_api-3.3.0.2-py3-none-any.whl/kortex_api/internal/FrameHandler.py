import threading
from concurrent.futures import Future

from ..exceptions.KException import KException
from ..exceptions.KClientException import KClientException
from ..exceptions.KServerException import KServerException

from ..autogen.messages import Frame_pb2 as FramePb
from ..autogen.messages import Errors_pb2 as ErrorsPb
from . import BitMaskTools

class _FrameHandler:
    def __init__(self):
        self._framePromise = {}
        self._mutex = threading.Lock()
        self._currentFrameId = 0

    def createRequestFrame(self, payload, serviceVersion, functionUid, deviceId, sessionId):
        with self._mutex:

            # Wrap around _currentFrameId to fit bits defined in header
            self._currentFrameId += 1 
            self._currentFrameId %= (BitMaskTools.message_infoMask_messageId + 1)

            frame = FramePb.Frame()

            serviceInfo = (serviceVersion << 28) + (functionUid.value & 0x0fffffff)
            frame.header.service_info = serviceInfo

            frame.header.message_info = BitMaskTools.changeFrameId(self._currentFrameId, frame.header.message_info)
            frame.header.message_info = BitMaskTools.changeSessionId(sessionId, frame.header.message_info)

            frame.header.frame_info = BitMaskTools.changeHeaderVersion(1, frame.header.frame_info)
            frame.header.frame_info = BitMaskTools.changeFrameType(FramePb.MSG_FRAME_REQUEST, frame.header.frame_info)
            frame.header.frame_info = BitMaskTools.changeDeviceId(deviceId, frame.header.frame_info)

            if payload is not None:
                frame.header.payload_info = BitMaskTools.changePayloadLength(len(payload), frame.header.payload_info)
                frame.payload = payload
            else:
                frame.header.payload_info = BitMaskTools.changePayloadLength(0, frame.header.payload_info)
                
            self._framePromise[self._currentFrameId] = Future()
            return (frame, self._currentFrameId, self._framePromise[self._currentFrameId])

    
    def manageResponseFrame(self, frame: FramePb):
        with self._mutex:
            cmdPromise = Future()
            error = FramePb.Error()

            frameId = BitMaskTools.extractFrameId(frame.header.message_info)

            if list(self._framePromise.keys()).count(frameId) > 0:
                cmdPromise = self._framePromise[frameId]

                if BitMaskTools.extractErrorCode(frame.header.frame_info) != ErrorsPb.ERROR_NONE:
                    server_ex = KServerException(frame)
                    cmdPromise.set_exception(server_ex)
                else:
                    cmdPromise.set_result(frame)

                del self._framePromise[frameId]
            else:
                error.error_code = ErrorsPb.ERROR_PROTOCOL_CLIENT
                error.error_sub_code = ErrorsPb.UNREGISTERED_FRAME_RECEIVED
                error.error_sub_string = "Unexpected frame received from server, frameId={}".format(frameId)

            return error

    def forcePromiseException(self, frameId, errorEx: KClientException):
        with self._mutex:
            if list(self._framePromise.keys()).count(frameId) > 0:
                cmdPromise = self._framePromise[frameId]
                cmdPromise.set_exception(errorEx)
                del self._framePromise[frameId]
            else:
                raise KException("Programmer error: forcePromiseException on non-existing frame msg id")
