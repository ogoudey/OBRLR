import threading

from ..exceptions.KException import KException

class _NotificationCallback:

    def __init__(self, callbackId, parseNotifDataFromString, callbackFct):
        self._callbackId = callbackId
        self._parseFromString = parseNotifDataFromString
        self._callback = callbackFct

    def __call__(self, payload):
        obj = self._parseFromString(payload)
        self._callback(obj)


class _NotificationKey:
    def __init__(self, namespace, serviceId, functionId):
        self._namespace = namespace
        self._serviceId = serviceId
        self._functionId = functionId

    def __hash__(self):
        return hash((self._namespace, self._serviceId, self._functionId))

    def __eq__(self, other):
        return ( ( self._namespace, self._serviceId, self._functionId) == ( other._namespace, other._serviceId, other._functionId) )

    def __str__(self):
        return "(namespace={},serviceId={},functionId={})".format(self._namespace, self._serviceId, self._functionId)

class _NotificationHandler:

    def __init__(self):
        
        # Dictionary for which:
        #   key = _NotificationKey 
        #   value = list of _NotificationCallback
        self._callbackDict = {}
        self._mutex = threading.Lock()

    def __del__(self):
        with self._mutex:
            self._callbackDict.clear()

    def addCallback(self, notifId:_NotificationKey, notifCallback:_NotificationCallback):
        with self._mutex:
            callbackList = self._callbackDict.get(notifId)
            if callbackList is None:
                callbackList = [notifCallback]
            else:
                callbackList.append(notifCallback)

            self._callbackDict[notifId] = callbackList

    def getNotifIdentifier(self, namespace, callbackId):
        with self._mutex:
            for notifId, callbackList in self._callbackDict.items():
                if notifId._namespace == namespace:
                    for callback in callbackList:
                        if callback._callbackId == callbackId:
                            return notifId
        return None

    # Delete callback and return remaining callback count for notifId 
    def deleteCallback(self, notifId:_NotificationKey, callbackId):
        with self._mutex:    
            callbackList = self._callbackDict.get(notifId)
            for i, c in enumerate(callbackList):
                if c._callbackId == callbackId:
                    del self._callbackDict[notifId][i]

                    return len(self._callbackDict[notifId])
                    
            raise ValueError("callback ID not found for notifId:" + str(notifId) + " and callbackId:" + str(callbackId))

    # Notify callbacks registered for given namespace and function Id
    def notifyCallbacks(self, notifId:_NotificationKey, frame):
        with self._mutex:
            callbackList = self._callbackDict.get(notifId)

            if (callbackList is None):
                raise KException("No callbacks found for notifId:" + str(notifId) )
            else:
                for callbackObj in callbackList:
                    callbackObj(frame)
