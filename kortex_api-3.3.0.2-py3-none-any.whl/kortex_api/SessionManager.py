"""This module imports the Session Manager, a special Session Client for UDP-based routers who need to create a session.  
"""
import inspect
import os
import sys
import threading
import time

from .autogen.client_stubs import SessionClientRpc as Session
from .autogen.messages import Frame_pb2 as FramePb  # NOQA
from .autogen.messages import Session_pb2
from .exceptions.KServerException import KServerException
from .MqttTransport import MqttTransport
from .RouterClient import RouterClient, RouterClientSendOptions


def DropConnectionTimeoutCallback():
    file_basename = '.'.join(os.path.basename(__file__).split('.')[:-1])    # strip extension (.py)
    print("[{}] Connection timeout detected ({})".format(file_basename, time.time()), file=sys.stderr)

class SessionManager(Session.SessionClient):
    """The SessionManager is a special SessionClient that is used with UDP (low-level) communication to create and close sessions.

    Kortex Routers created with a :class:`~kortex_api.UDPTransport` have to create a session with the :class:`~kortex_api.SessionManager` to properly interact with a Kortex device.

    Kortex Routers created with a :class:`~kortex_api.MqttTransport` have to create a session using the auto-generated SessionClient.

    **Usage :**
    ::
    
        # Create the UDPTransport, RouterClient and connect the transport...

        sessionManager = SessionManager(router)

        # Fill a CreateSessionInfo with the proper authentification information...

        sessionManager.CreateSession(createSessionInfo)

        # Run your app and before deactivating the RouterClient, close the session

        sessionManager.CloseSession()
    """

    def __init__(self, router: RouterClient, connectionTimeoutCallback = DropConnectionTimeoutCallback):
        """Constructor for SessionManager.

        Args:
            router (RouterClient): RouterClient that this SessionManager will use to communicate.
            connectionTimeoutCallback (function, optional): Custom callback when the connection is dropped. Defaults to DropConnectionTimeoutCallback.

        Raises:
            RuntimeError: If the :class:`~kortex_api.RouterClient` was created with an :class:`~kortex_api.MqttTransport`, the exception is raised. 
        """
        if isinstance(router._transport, MqttTransport): 
            raise RuntimeError('SessionManager class does not support Mqtt transport. Please use SessionClientRpc instead.')
        router._registerHitCallback(self._hit)
        # Callback notifying the application that current 'User Session' lost communication (no Rx) longer than 'inactivityTimeout_ms'
        self._connectionTimeoutCallback = connectionTimeoutCallback
        self._keepAliveInterval_ms = 150
        self._event = threading.Event()
        self._thread = threading.Thread(target=self._sessionValidationThread)
        self._thread.daemon = True
        self._hasBeenSent = False
        self._hasBeenReceived = False
        super().__init__(router)

    def __del__(self):
        self._event.set()
        if self._thread.is_alive():
            self._thread.join(timeout=2)

    def CreateSession(self, createSessionInfo: Session_pb2.CreateSessionInfo, options:RouterClientSendOptions = RouterClientSendOptions()):
        """Attempts to create a session with the supplied CreateSessionInfo.

        Args:
            createSessionInfo (Session_pb2.CreateSessionInfo): Authentification information for session creation.
            options (RouterClientSendOptions, optional): Router sending options. Defaults to RouterClientSendOptions().

        Raises:
            TimeoutError: The call has timed out and the session was not created.
        """
        try:
            super().CreateSession(createSessionInfo, options=options)
            self.m_inactivityTimeout_ms = createSessionInfo.session_inactivity_timeout
            self._thread.start()
        except TimeoutError:
            # reraise Timeout if no other exception was raised
            raise


    def CloseSession(self, options:RouterClientSendOptions = RouterClientSendOptions()):
        """Closes the session.

        Args:
            options (RouterClientSendOptions, optional): Router sending options. Defaults to RouterClientSendOptions().

        Raises:
            TimeoutError: The call has timed out.
            Exception: Any other error has happened with the call.
        """
        self.router._hitCallback = None     # Unregister hit callback from router
        self._event.set()
        time.sleep(0.010)
        try:
            super().CloseSession(options=options)
        except TimeoutError:
            pass
        except Exception as ex:
            print("[{}.{}] super().CloseSession() failed with: {}".format(self.__class__.__name__, inspect.stack()[0][3], ex), file=sys.stderr, flush=True)

    def _hit(self, hit_type: FramePb.FrameTypes):
        if hit_type is FramePb.MSG_FRAME_RESPONSE:
            self._hasBeenReceived = True
        elif hit_type is FramePb.MSG_FRAME_REQUEST:
            self._hasBeenSent = True


    def _sessionValidationThread(self):
        try:
            lastRcvTimeStamp = time.time();
            lastSendTimeStamp = time.time();

            options = RouterClientSendOptions()
            options.timeout_ms = self._keepAliveInterval_ms * 0.80

            keepAliveInterval_sec = self._keepAliveInterval_ms / 1000
            inactivityTimeout_sec = self.m_inactivityTimeout_ms / 1000   # Session inactivity timeout in second

            while not self._event.is_set():
                now = time.time()
                
                if not self._hasBeenSent and (now - lastSendTimeStamp) > keepAliveInterval_sec:
                    lastSendTimeStamp = time.time() # reset the time stamp because missing non-blocking version
                    try:
                        self.KeepAlive(options=options)
                    except TimeoutError:
                        pass
                elif self._hasBeenSent:
                    lastSendTimeStamp = time.time()
                    self._hasBeenSent = False

                if not self._hasBeenReceived and inactivityTimeout_sec and (now - lastRcvTimeStamp) > inactivityTimeout_sec:
                    lastRcvTimeStamp = time.time()      # to make sure we don't trig the connection timeout callback every iteration after the first timeout
                    self._connectionTimeoutCallback()
                elif self._hasBeenReceived:
                    lastRcvTimeStamp = time.time()
                    self._hasBeenReceived = False

                time.sleep(0.010)   # 10 milliseconds

        except KServerException as e:
            print(e)
