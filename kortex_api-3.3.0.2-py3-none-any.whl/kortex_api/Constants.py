"""This module contains definitions of constants that are used in the Kortex API. 
"""

DEFAULT_CONTROLLER_ADDRESS = '192.168.1.10'
"""The default controller ip address."""

DEFAULT_MQTT_BROKER_PORT = 1883
"""The default MQTT broker port."""

DEFAULT_MQTT_TIMEOUT_SEC = 10
"""The default MQTT timeout (in seconds)."""

DEFAULT_UDP_PORT = 10001
"""The default UDP Transport port."""