from enum import Enum

class ServiceIds(Enum):
    eIdBaseCyclic = 3
    eIdIndustrialIO = 36
    eIdVariableManager = 40
    eIdSession = 1
    eIdPluginManager = 33
    eIdPlugin = 31
    eIdProgramConfig = 34
    eIdProgramRunner = 35
    eIdDeviceConfig = 9
    eIdDeviceManager = 23
    eIdEditingContext = 45
    eIdActuatorCyclic = 11
    eIdActuatorConfig = 10
    eIdBase = 2
    eIdModbus = 32
    eIdEventBroker = 49
    eIdTest = 4080
    eIdSoftwareUpdate = 51
    eIdControllerDevices = 50
    eIdProtectionZone = 46
    eIdToolManager = 43
    eIdToolPlugin = 42
    eIdControlConfig = 16
    eIdSafetyIO = 47
    eIdWristConfigC61 = 44
    eIdWristCyclic = 39
    eIdSafetyFunctions = 41
    eIdSafetyControlUnitConfig = 48
