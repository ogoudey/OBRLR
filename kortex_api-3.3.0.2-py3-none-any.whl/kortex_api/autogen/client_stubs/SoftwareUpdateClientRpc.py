
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import SoftwareUpdate_pb2 as SoftwareUpdatePb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class SoftwareUpdateFunctionUid(Enum):
    uidUpgradeSWU = 0x330001
    uidGetSWUVersion = 0x330002



class SoftwareUpdateClient():
    
    serviceVersion = 1
    serviceId = 51

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a SoftwareUpdateClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


