
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import Session_pb2 as SessionPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class SessionFunctionUid(Enum):
    uidCreateSession = 0x10001
    uidCloseSession = 0x10002
    uidKeepAlive = 0x10003
    uidGetConnections = 0x10004
    uidAddTemporaryUserRole = 0x10005
    uidRemoveTemporaryUserRole = 0x10006
    uidSetAccessControl = 0x10007
    uidGetAccessControl = 0x10008



class SessionClient():
    
    serviceVersion = 1
    serviceId = 1

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a SessionClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def CreateSession(self, createsessioninfo: SessionPb.CreateSessionInfo, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Creates a new session on the robot using given values for user name, session timeout value, and password
        """
        reqPayload = createsessioninfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SessionFunctionUid.uidCreateSession, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def CloseSession(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Closes an existing open session
        """


        future = self.router._send(None, self.serviceVersion, SessionFunctionUid.uidCloseSession, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def KeepAlive(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends message to robot to keep current session alive
        """


        future = self.router._send(None, self.serviceVersion, SessionFunctionUid.uidKeepAlive, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def AddTemporaryUserRole(self, temporaryrolerequest: SessionPb.TemporaryRoleRequest, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Adds a temporary role to a user's session
        """
        reqPayload = temporaryrolerequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SessionFunctionUid.uidAddTemporaryUserRole, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def RemoveTemporaryUserRole(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Removes the temporary role to a user's session
        """


        future = self.router._send(None, self.serviceVersion, SessionFunctionUid.uidRemoveTemporaryUserRole, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





