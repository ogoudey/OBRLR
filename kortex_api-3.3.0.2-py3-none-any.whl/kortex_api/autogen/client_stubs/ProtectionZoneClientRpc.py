
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ProtectionZone_pb2 as ProtectionZonePb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ProtectionZoneFunctionUid(Enum):
    uidCreateProtectionZone = 0x2e0001
    uidUpdateProtectionZone = 0x2e0002
    uidReadProtectionZone = 0x2e0003
    uidDeleteProtectionZone = 0x2e0004
    uidReadAllProtectionZones = 0x2e0005
    uidSetToolSphere = 0x2e0006
    uidGetToolSphere = 0x2e0007
    uidOnNotificationProtectionZoneChangeTopic = 0x2e0008
    uidOnNotificationToolSphereChangeTopic = 0x2e0009
    uidUnsubscribe = 0x2e000a



class ProtectionZoneClient():
    
    serviceVersion = 1
    serviceId = 46

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ProtectionZoneClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def CreateProtectionZone(self, protectionzoneconfig: ProtectionZonePb.ProtectionZoneConfig, deviceId: int = 0, options = RouterClientSendOptions()) -> ProtectionZonePb.ProtectionZoneHandle :
        """
        Creates a new protection zone and returns a handle to the protection zone.
        The arm must be powered off and not be in an Unrecoverable Fault state to create a protection zone.
        The parameter orientation from the ZoneShape needs to be an orthonormal matrix, or else an error ERROR_DEVICE, METHOD_FAILED, is raised.
        If the shape dimensions are not greater than 0, an the error ERROR_DEVICE, METHOD_FAILED is raised.
        The shape dimensions are entered in meters and must be initialized according to the shape_type. The order is important and must be as followed:
        The dimensions must contain the radius it is a sphere, the x, y and z (length, width, height) dimensions if it is a rectangular prism, the radius and height if it is a cylinder.
        The shape origin needs to be a three dimensional vector that corresponds to the x,y,z coordinates.
        
        """
        reqPayload = protectionzoneconfig.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidCreateProtectionZone, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.ProtectionZoneHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def UpdateProtectionZone(self, protectionzoneconfig: ProtectionZonePb.ProtectionZoneConfig, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Updates an existing protection zone
        The arm must be powered off and not be in an Unrecoverable Fault state to update a protection zone.
        Updates on the protection zone fields need to follow the same rules as the ones mentioned in CreateProtectionZone's description.
        The handle.identifier of the protection zone to be updated needs to match the identifier from an existing protection zone, or else an ENTITY_NOT_FOUND exception is thrown.
        
        """
        reqPayload = protectionzoneconfig.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidUpdateProtectionZone, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ReadProtectionZone(self, protectionzonehandle: ProtectionZonePb.ProtectionZoneHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> ProtectionZonePb.ProtectionZoneConfig :
        """
        Retrieves an existing protection zone
        """
        reqPayload = protectionzonehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidReadProtectionZone, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.ProtectionZoneConfig()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteProtectionZone(self, protectionzonehandle: ProtectionZonePb.ProtectionZoneHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes an existing protection zone
        The arm must be powered off and not be in an Unrecoverable Fault state to delete a protection zone.
        The handle.identifier of the protection zone to be deleted needs to match the identifier from an existing protection zone, or else an ENTITY_NOT_FOUND exception is thrown.
        
        """
        reqPayload = protectionzonehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidDeleteProtectionZone, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ReadAllProtectionZones(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ProtectionZonePb.ProtectionZoneConfigList :
        """
        Retrieves a list of all protection zones
        """


        future = self.router._send(None, self.serviceVersion, ProtectionZoneFunctionUid.uidReadAllProtectionZones, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.ProtectionZoneConfigList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetToolSphere(self, toolsphere: ProtectionZonePb.ToolSphere, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the tool sphere.
        The arm must be powered off and not be in an Unrecoverable Fault state to set the tool sphere.
        
        """
        reqPayload = toolsphere.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidSetToolSphere, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetToolSphere(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ProtectionZonePb.ToolSphere :
        """
        Gets the tool sphere
        """


        future = self.router._send(None, self.serviceVersion, ProtectionZoneFunctionUid.uidGetToolSphere, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.ToolSphere()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationProtectionZoneChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidOnNotificationProtectionZoneChangeTopic, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProtectionZonePb.ProtectionZoneChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProtectionZoneFunctionUid.uidOnNotificationProtectionZoneChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationToolSphereChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidOnNotificationToolSphereChangeTopic, deviceId, self.namespace, options)

        ansPayload = ProtectionZonePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProtectionZonePb.ToolSphereChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProtectionZoneFunctionUid.uidOnNotificationToolSphereChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ProtectionZoneFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

