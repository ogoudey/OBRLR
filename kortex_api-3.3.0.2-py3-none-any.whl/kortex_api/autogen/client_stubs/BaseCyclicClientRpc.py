
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import BaseCyclic_pb2 as BaseCyclicPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class BaseCyclicFunctionUid(Enum):
    uidRefresh = 0x30001
    uidRefreshCommand = 0x30002
    uidRefreshFeedback = 0x30003
    uidRefreshCustomData = 0x30004



class BaseCyclicClient():
    
    serviceVersion = 1
    serviceId = 3

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a BaseCyclicClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def RefreshFeedback(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BaseCyclicPb.Feedback :
        """
        Obtains feedback from base, actuators, and interface on their status
        """
        """
        Sends a command to actuators and interface and returns feedback from base, actuators, and interface on current status
        """


        future = self.router._send(None, self.serviceVersion, BaseCyclicFunctionUid.uidRefreshFeedback, deviceId, self.namespace, options)

        ansPayload = BaseCyclicPb.Feedback()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

