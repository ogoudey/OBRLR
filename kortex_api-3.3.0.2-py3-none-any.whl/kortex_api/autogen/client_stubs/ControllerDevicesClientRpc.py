
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ControllerDevices_pb2 as ControllerDevicesPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ControllerDevicesFunctionUid(Enum):
    uidGetStorageList = 0x320001
    uidGetFileSystemList = 0x320002
    uidGetLocalUpdateFileList = 0x320003
    uidFileWrite = 0x320004
    uidFileRead = 0x320005
    uidOnNotificationStorageTopic = 0x320006
    uidUnsubscribe = 0x320007
    uidGetConnectedDevicesList = 0x320008



class ControllerDevicesClient():
    
    serviceVersion = 1
    serviceId = 50

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ControllerDevicesClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def GetStorageList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.StorageMountPointList :
        """
        Get available storage mount points
        """


        future = self.router._send(None, self.serviceVersion, ControllerDevicesFunctionUid.uidGetStorageList, deviceId, self.namespace, options)

        ansPayload = ControllerDevicesPb.StorageMountPointList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetFileSystemList(self, fslistargs: CommonPb.FSListArgs, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.FSItemList :
        """
        Retrieves file system item list (files and directories) from given path.
        The path must be part of a mount point (e.g.: USB drives).
        
        """
        reqPayload = fslistargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidGetFileSystemList, deviceId, self.namespace, options)

        ansPayload = ControllerDevicesPb.FSItemList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def FileWrite(self, fswriteargs: CommonPb.FSWriteArgs, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Write text data to a file specified by given path. Directories are created if they do not exist.
        The path must be part of a mount point (e.g.: USB drives).
        
        """
        reqPayload = fswriteargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidFileWrite, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def FileRead(self, fsreadargs: CommonPb.FSReadArgs, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.FSReadData :
        """
        Read text data from file specified by given path.
        The path must be part of a mount point (e.g.: USB drives).
        
        """
        reqPayload = fsreadargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidFileRead, deviceId, self.namespace, options)

        ansPayload = ControllerDevicesPb.FSReadData()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationStorageTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidOnNotificationStorageTopic, deviceId, self.namespace, options)

        ansPayload = ControllerDevicesPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ControllerDevicesPb.StorageEventNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ControllerDevicesFunctionUid.uidOnNotificationStorageTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

