
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import DeviceConfig_pb2 as DeviceConfigPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class DeviceConfigFunctionUid(Enum):
    uidGetRunMode = 0x90001
    uidSetRunMode = 0x90002
    uidGetDeviceType = 0x90003
    uidGetFirmwareVersion = 0x90004
    uidGetBootloaderVersion = 0x90005
    uidGetModelNumber = 0x90006
    uidGetPartNumber = 0x90007
    uidGetSerialNumber = 0x90008
    uidGetMACAddress = 0x90009
    uidGetIPv4Settings = 0x9000a
    uidSetIPv4Settings = 0x9000b
    uidGetPartNumberRevision = 0x9000c
    uidRebootRequest = 0x9000e
    uidSetDiagnosticEnable = 0x9000f
    uidSetDiagnosticErrorThreshold = 0x90010
    uidSetDiagnosticWarningThreshold = 0x90011
    uidSetDiagnosticConfiguration = 0x90012
    uidGetDiagnosticConfiguration = 0x90013
    uidGetDiagnosticInformation = 0x90014
    uidGetDiagnosticEnable = 0x90015
    uidGetDiagnosticStatus = 0x90016
    uidClearAllDiagnosticStatus = 0x90017
    uidClearDiagnosticStatus = 0x90018
    uidGetAllDiagnosticConfiguration = 0x90019
    uidGetAllDiagnosticInformation = 0x9001a
    uidResetDiagnosticDefaults = 0x9001b
    uidOnNotificationDiagnosticTopic = 0x9001c
    uidExecuteCalibration = 0x90022
    uidGetCalibrationResult = 0x90023
    uidStopCalibration = 0x90024



class DeviceConfigClient():
    
    serviceVersion = 1
    serviceId = 9

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a DeviceConfigClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def GetDeviceType(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.DeviceType :
        """
        Retrieves the type for the device
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetDeviceType, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.DeviceType()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetFirmwareVersion(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.FirmwareVersion :
        """
        Retrieves the device firmware version
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetFirmwareVersion, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.FirmwareVersion()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetBootloaderVersion(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.BootloaderVersion :
        """
        Retrieves the device bootloader version
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetBootloaderVersion, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.BootloaderVersion()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetModelNumber(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.ModelNumber :
        """
        Retrieves the device model number
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetModelNumber, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.ModelNumber()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetPartNumber(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.PartNumber :
        """
        Retrieves the device part number
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetPartNumber, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.PartNumber()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetSerialNumber(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.SerialNumber :
        """
        Retrieves the device serial number
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetSerialNumber, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.SerialNumber()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetMACAddress(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.MACAddress :
        """
        Retrieves the device MAC address
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetMACAddress, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.MACAddress()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetPartNumberRevision(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceConfigPb.PartNumberRevision :
        """
        Retrieves the device part number revision
        """
        """
        Retrieves the device part number
        """


        future = self.router._send(None, self.serviceVersion, DeviceConfigFunctionUid.uidGetPartNumberRevision, deviceId, self.namespace, options)

        ansPayload = DeviceConfigPb.PartNumberRevision()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

