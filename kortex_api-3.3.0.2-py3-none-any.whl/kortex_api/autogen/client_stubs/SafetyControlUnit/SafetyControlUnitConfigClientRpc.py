
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from .... import  *
from ....internal.NotificationHandler import _NotificationCallback
from ....internal import BitMaskTools
from ...messages import SafetyControlUnitConfig_pb2 as SafetyControlUnitConfigPb  # NOQA
from ...messages import Common_pb2 as CommonPb  # NOQA



class SafetyControlUnitConfigFunctionUid(Enum):
    uidSetArmCalibration = 0x300001
    uidGetMpuSafetyParametersChecksum = 0x300002
    uidValidateSafetyParametersChecksum = 0x300003
    uidOnNotificationSafetyParametersChecksumChangeTopic = 0x300004
    uidUnsubscribe = 0x300005



class SafetyControlUnitConfigClient():
    
    serviceVersion = 1
    serviceId = 48

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a SafetyControlUnitConfigClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def GetMpuSafetyParametersChecksum(self, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.CRC32Checksum :
        """
        Gets safety parameters checksum from MPU
        """


        future = self.router._send(None, self.serviceVersion, SafetyControlUnitConfigFunctionUid.uidGetMpuSafetyParametersChecksum, deviceId, self.namespace, options)

        ansPayload = SafetyControlUnitConfigPb.CRC32Checksum()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationSafetyParametersChecksumChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyControlUnitConfigFunctionUid.uidOnNotificationSafetyParametersChecksumChangeTopic, deviceId, self.namespace, options)

        ansPayload = SafetyControlUnitConfigPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = SafetyControlUnitConfigPb.SafetyParametersChecksumChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(SafetyControlUnitConfigFunctionUid.uidOnNotificationSafetyParametersChecksumChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, SafetyControlUnitConfigFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

