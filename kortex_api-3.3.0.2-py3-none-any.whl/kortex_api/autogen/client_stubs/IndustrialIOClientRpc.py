
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import IndustrialIO_pb2 as IndustrialIOPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class IndustrialIOFunctionUid(Enum):
    uidSetDigitalOutputConfiguration = 0x240001
    uidGetDigitalOutputConfiguration = 0x240002
    uidSetDigitalOutputHighState = 0x240003
    uidSetDigitalOutputLowState = 0x240004
    uidGetDigitalOutputInfo = 0x240005
    uidGetAllDigitalOutputInfo = 0x240006
    uidSetDigitalInputConfiguration = 0x240007
    uidGetDigitalInputConfiguration = 0x240008
    uidGetDigitalInputInfo = 0x240009
    uidGetAllDigitalInputInfo = 0x24000a
    uidSetAnalogIOConfiguration = 0x24000b
    uidGetAnalogIOConfiguration = 0x24000c
    uidSetAnalogValue = 0x24000d
    uidGetAnalogIOInfo = 0x24000e
    uidGetAllAnalogIOInfo = 0x24000f
    uidClearFaults = 0x240010
    uidUnsubscribe = 0x240011
    uidOnNotificationDigitalOutputChangeTopic = 0x240012
    uidOnNotificationDigitalInputChangeTopic = 0x240013
    uidOnNotificationAnalogIOChangeTopic = 0x240014
    uidOnNotificationWristAnalogIOChangeTopic = 0x240015



class IndustrialIOClient():
    
    serviceVersion = 1
    serviceId = 36

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a IndustrialIOClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetDigitalOutputConfiguration(self, digitaloutputconfiguration: IndustrialIOPb.DigitalOutputConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Configures a digital output channel.
        The channel.identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitaloutputconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetDigitalOutputConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDigitalOutputConfiguration(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalOutputConfiguration :
        """
        Retrieves a digital output configuration for a specific channel.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetDigitalOutputConfiguration, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalOutputConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetDigitalOutputHighState(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a digital output channel to a high state.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetDigitalOutputHighState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetDigitalOutputLowState(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a digital output channel to a low state.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetDigitalOutputLowState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDigitalOutputInfo(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalOutputInfo :
        """
        Retrieves a digital output channel information.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetDigitalOutputInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalOutputInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllDigitalOutputInfo(self, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalOutputInfoList :
        """
        Retrieves all digital output channel information.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """


        future = self.router._send(None, self.serviceVersion, IndustrialIOFunctionUid.uidGetAllDigitalOutputInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalOutputInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetDigitalInputConfiguration(self, digitalinputconfiguration: IndustrialIOPb.DigitalInputConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Configures a digital input channel.
        The channel.identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalinputconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetDigitalInputConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDigitalInputConfiguration(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalInputConfiguration :
        """
        Retrieves a digital input configuration for a specific channel.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetDigitalInputConfiguration, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalInputConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetDigitalInputInfo(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalInputInfo :
        """
        Retrieves a digital input channel information.
        The identifier must be between 1 and 8.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetDigitalInputInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalInputInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllDigitalInputInfo(self, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalInputInfoList :
        """
        Retrieves all digital input channel informaion.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """


        future = self.router._send(None, self.serviceVersion, IndustrialIOFunctionUid.uidGetAllDigitalInputInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.DigitalInputInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAnalogIOConfiguration(self, analogioconfiguration: IndustrialIOPb.AnalogIOConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Configures an analog input/output channel.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = analogioconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetAnalogIOConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAnalogIOConfiguration(self, analogiochannelidentifier: IndustrialIOPb.AnalogIOChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOConfiguration :
        """
        Retrieves an analog input/output configuration for a specific channel.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = analogiochannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetAnalogIOConfiguration, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.AnalogIOConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAnalogValue(self, analogoutput: IndustrialIOPb.AnalogOutput, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets an analog value on a channel.
        The dac_value is the value to set, either in V or mA.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        An ERROR_INTERNAL will be thrown if the channel is not configured as an output also.
        An ERROR_DEVICE, ENTITY_NOT_FOUND will be thrown if the dac_value is out of bounds. The exception message will contain the limits.
        
        """
        reqPayload = analogoutput.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidSetAnalogValue, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAnalogIOInfo(self, analogiochannelidentifier: IndustrialIOPb.AnalogIOChannelIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOInfo :
        """
        Retrieves an analog input/output channel information.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """
        reqPayload = analogiochannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidGetAnalogIOInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.AnalogIOInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllAnalogIOInfo(self, deviceId: int = 0, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOInfoList :
        """
        Retrieves all analog input/output channel information.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """


        future = self.router._send(None, self.serviceVersion, IndustrialIOFunctionUid.uidGetAllAnalogIOInfo, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.AnalogIOInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ClearFaults(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Clears digital and analog I/O faults.
        An ERROR_INTERNAL will be thrown if the I/O board is not powered up.
        
        """


        future = self.router._send(None, self.serviceVersion, IndustrialIOFunctionUid.uidClearFaults, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic.
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def OnNotificationDigitalOutputChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidOnNotificationDigitalOutputChangeTopic, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = IndustrialIOPb.DigitalOutputChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(IndustrialIOFunctionUid.uidOnNotificationDigitalOutputChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationDigitalInputChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidOnNotificationDigitalInputChangeTopic, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = IndustrialIOPb.DigitalInputChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(IndustrialIOFunctionUid.uidOnNotificationDigitalInputChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationAnalogIOChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidOnNotificationAnalogIOChangeTopic, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = IndustrialIOPb.AnalogIOChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(IndustrialIOFunctionUid.uidOnNotificationAnalogIOChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationWristAnalogIOChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, IndustrialIOFunctionUid.uidOnNotificationWristAnalogIOChangeTopic, deviceId, self.namespace, options)

        ansPayload = IndustrialIOPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = IndustrialIOPb.AnalogIOChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(IndustrialIOFunctionUid.uidOnNotificationWristAnalogIOChangeTopic, self.namespace, notifCallback)
        return ansPayload

