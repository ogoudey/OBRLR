
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ActuatorConfig_pb2 as ActuatorConfigPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ActuatorConfigFunctionUid(Enum):
    uidGetAxisOffsets = 0xa0001
    uidSetAxisOffsets = 0xa0002
    uidReadTorqueCalibration = 0xa0003
    uidWriteTorqueCalibration = 0xa0004
    uidSetTorqueOffset = 0xa0005
    uidGetControlMode = 0xa0006
    uidSetControlMode = 0xa0007
    uidGetActivatedControlLoop = 0xa0008
    uidSetActivatedControlLoop = 0xa0009
    uidGetVectorDriveParameters = 0xa000a
    uidSetVectorDriveParameters = 0xa000b
    uidGetEncoderDerivativeParameters = 0xa000c
    uidSetEncoderDerivativeParameters = 0xa000d
    uidGetControlLoopParameters = 0xa000e
    uidSetControlLoopParameters = 0xa000f
    uidStartFrequencyResponse = 0xa0010
    uidStopFrequencyResponse = 0xa0011
    uidStartStepResponse = 0xa0012
    uidStopStepResponse = 0xa0013
    uidStartRampResponse = 0xa0014
    uidStopRampResponse = 0xa0015
    uidSelectCustomData = 0xa0016
    uidGetSelectedCustomData = 0xa0017
    uidSetCommandMode = 0xa0018
    uidClearFaults = 0xa0019
    uidSetServoing = 0xa001a
    uidMoveToPosition = 0xa001b
    uidGetCommandMode = 0xa001c
    uidGetServoing = 0xa001d
    uidGetTorqueOffset = 0xa001e
    uidSetCoggingFeedforwardMode = 0xa001f
    uidGetCoggingFeedforwardMode = 0xa0020
    uidReadLookupTable = 0xa0021
    uidWriteLookupTable = 0xa0022
    uidUpdateNVMTableFromLookupTable = 0xa0023
    uidWriteJointPositionSensorOffset = 0xa0024
    uidWriteMotorPositionToJointPositionSensorOffset = 0xa0025
    uidSetMotorPowerFilterPeriod = 0xa0026
    uidGetMotorPowerFilterPeriod = 0xa0027
    uidWriteCurrentOffset = 0xa0028
    uidGetJointEncoderFaults = 0xa0029
    uidReadFourierModel = 0xa002a
    uidWriteFourierModel = 0xa002b
    uidWriteTorqueBasedMotorPositionSensorOffset = 0xa002c
    uidConfirmJointPosition = 0xa002d
    uidReadGearboxHysteresisCalibration = 0xa002e
    uidWriteGearboxHysteresisCalibration = 0xa002f
    uidGetMotorParameters = 0xa0030
    uidGetGearboxParameters = 0xa0031



class ActuatorConfigClient():
    
    serviceVersion = 1
    serviceId = 10

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ActuatorConfigClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


