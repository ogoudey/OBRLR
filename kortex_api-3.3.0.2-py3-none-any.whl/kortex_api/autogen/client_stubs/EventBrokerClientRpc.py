
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import EventBroker_pb2 as EventBrokerPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class EventBrokerFunctionUid(Enum):
    uidLogEvent = 0x310001
    uidLogEvents = 0x310002
    uidGetEvents = 0x310003
    uidClearEvent = 0x310004
    uidClearAllEvents = 0x310005
    uidOnNotificationEventTopic = 0x310006
    uidUnsubscribe = 0x310007



class EventBrokerClient():
    
    serviceVersion = 1
    serviceId = 49

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a EventBrokerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def LogEvent(self, event: EventBrokerPb.Event, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Log an event
        """
        reqPayload = event.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidLogEvent, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def LogEvents(self, eventlist: EventBrokerPb.EventList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Log a list of events
        """
        """
        Log an event
        """
        reqPayload = eventlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidLogEvents, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetEvents(self, geteventsparameter: EventBrokerPb.GetEventsParameter, deviceId: int = 0, options = RouterClientSendOptions()) -> EventBrokerPb.EventList :
        """
        Get the list of persisted events
        """
        reqPayload = geteventsparameter.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidGetEvents, deviceId, self.namespace, options)

        ansPayload = EventBrokerPb.EventList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ClearEvent(self, eventhandle: EventBrokerPb.EventHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Clear one persisted event
        Error thrown (ERROR_INTERNAL, METHOD_FAILED) if the input parameter EventHandle is not from an event that has been previously logged
        or if it has already been cleared.
        
        """
        reqPayload = eventhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidClearEvent, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ClearAllEvents(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Clear all persisted events
        """


        future = self.router._send(None, self.serviceVersion, EventBrokerFunctionUid.uidClearAllEvents, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationEventTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidOnNotificationEventTopic, deviceId, self.namespace, options)

        ansPayload = EventBrokerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = EventBrokerPb.EventNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(EventBrokerFunctionUid.uidOnNotificationEventTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, EventBrokerFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

