
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import Modbus_pb2 as ModbusPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ModbusFunctionUid(Enum):
    uidReadCoils = 0x200001
    uidReadDiscreteInputs = 0x200002
    uidReadHoldingRegisters = 0x200003
    uidReadInputRegisters = 0x200004
    uidWriteSingleCoil = 0x200005
    uidWriteSingleHoldRegister = 0x200006
    uidWriteMultipleCoils = 0x200007
    uidWriteMultipleHoldRegisters = 0x200008
    uidInitConnection = 0x200009
    uidCloseConnection = 0x20000b



class ModbusClient():
    
    serviceVersion = 1
    serviceId = 32

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ModbusClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def ReadCoils(self, readrequest: ModbusPb.ReadRequest, deviceId: int = 0, options = RouterClientSendOptions()) -> ModbusPb.ReadCoilResponse :
        """
        MODBUS function code 1.
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = readrequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidReadCoils, deviceId, self.namespace, options)

        ansPayload = ModbusPb.ReadCoilResponse()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadDiscreteInputs(self, readrequest: ModbusPb.ReadRequest, deviceId: int = 0, options = RouterClientSendOptions()) -> ModbusPb.ReadCoilResponse :
        """
        MODBUS function code 2
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = readrequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidReadDiscreteInputs, deviceId, self.namespace, options)

        ansPayload = ModbusPb.ReadCoilResponse()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadHoldingRegisters(self, readrequest: ModbusPb.ReadRequest, deviceId: int = 0, options = RouterClientSendOptions()) -> ModbusPb.ReadRegisterResponse :
        """
        MODBUS function code 3
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = readrequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidReadHoldingRegisters, deviceId, self.namespace, options)

        ansPayload = ModbusPb.ReadRegisterResponse()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadInputRegisters(self, readrequest: ModbusPb.ReadRequest, deviceId: int = 0, options = RouterClientSendOptions()) -> ModbusPb.ReadRegisterResponse :
        """
        MODBUS function code 4
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = readrequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidReadInputRegisters, deviceId, self.namespace, options)

        ansPayload = ModbusPb.ReadRegisterResponse()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def WriteSingleCoil(self, singlecoilwriterequest: ModbusPb.SingleCoilWriteRequest, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        MODBUS function code 5
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = singlecoilwriterequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidWriteSingleCoil, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def WriteSingleHoldRegister(self, singleregisterwriterequest: ModbusPb.SingleRegisterWriteRequest, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        MODBUS function code 6
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = singleregisterwriterequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidWriteSingleHoldRegister, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def WriteMultipleCoils(self, multiplecoilswriterequest: ModbusPb.MultipleCoilsWriteRequest, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        MODBUS function code 15
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = multiplecoilswriterequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidWriteMultipleCoils, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def WriteMultipleHoldRegisters(self, multipleregisterswriterequest: ModbusPb.MultipleRegistersWriteRequest, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        MODBUS function code 16
        A DEVICE_READY error will be thrown if no connection has been initialized with InitConnection.
        
        """
        reqPayload = multipleregisterswriterequest.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidWriteMultipleHoldRegisters, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def InitConnection(self, connectionparameters: ModbusPb.ConnectionParameters, deviceId: int = 0, options = RouterClientSendOptions()) -> ModbusPb.ClientHandle :
        """
        Initialize a connection with a MODBUS server (slave). Returns a client handle for the created connection.
        To connect with the Wrist, the ip_address should be "10.10.0.16" and the port should be 502.
        An INVALID_DEVICE error will be thrown if the device ID is invalid or if the connection to the given device ID fails to be established.
        
        """
        reqPayload = connectionparameters.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidInitConnection, deviceId, self.namespace, options)

        ansPayload = ModbusPb.ClientHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def CloseConnection(self, clienthandle: ModbusPb.ClientHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Close the connection to MODBUS server (slave) associated to the client handle given in arguments.
        
        """
        reqPayload = clienthandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ModbusFunctionUid.uidCloseConnection, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





