
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ToolPlugin_pb2 as ToolPluginPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ToolPluginFunctionUid(Enum):
    uidJog = 0x2a0001
    uidGetToolInformation = 0x2a0002
    uidGetToolsInformation = 0x2a0003
    uidGetToolFeedback = 0x2a0004
    uidOnNotificationToolInformationTopic = 0x2a0005
    uidUnsubscribe = 0x2a0006
    uidMoveRelative = 0x2a0007



class ToolPluginClient():
    
    serviceVersion = 1
    serviceId = 42

    def __init__(self, router: RouterClient, namespace: str):
        """Constructs a ToolPluginClient with an initialized RouterClient and a namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def Jog(self, jogmessage: ToolPluginPb.JogMessage, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = jogmessage.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidJog, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetToolInformation(self, toolhandle: ToolPluginPb.ToolHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolInformation :
        reqPayload = toolhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidGetToolInformation, deviceId, self.namespace, options)

        ansPayload = ToolPluginPb.ToolInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetToolsInformation(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolInformationList :


        future = self.router._send(None, self.serviceVersion, ToolPluginFunctionUid.uidGetToolsInformation, deviceId, self.namespace, options)

        ansPayload = ToolPluginPb.ToolInformationList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetToolFeedback(self, toolhandle: ToolPluginPb.ToolHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.CustomData :
        reqPayload = toolhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidGetToolFeedback, deviceId, self.namespace, options)

        ansPayload = ToolPluginPb.CustomData()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationToolInformationTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidOnNotificationToolInformationTopic, deviceId, self.namespace, options)

        ansPayload = ToolPluginPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ToolPluginPb.ToolInformationNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ToolPluginFunctionUid.uidOnNotificationToolInformationTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def MoveRelative(self, movemessage: ToolPluginPb.MoveMessage, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = movemessage.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolPluginFunctionUid.uidMoveRelative, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





