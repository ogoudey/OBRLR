
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ..... import  *
from .....internal.NotificationHandler import _NotificationCallback
from .....internal import BitMaskTools
from ....messages import WristConfigC61_pb2 as WristConfigC61Pb  # NOQA
from ....messages import IndustrialIO_pb2 as IndustrialIOPb  # NOQA
from ....messages import WristConfigC61_pb2 as WristConfigPb # NOQA
from ....messages import DeviceConfig_pb2 as DeviceConfigPb  # NOQA
from ....messages import Common_pb2 as CommonPb  # NOQA



class WristConfigC61FunctionUid(Enum):
    uidSetDigitalIOConfiguration = 0x2c0001
    uidGetDigitalIOConfiguration = 0x2c0002
    uidSetDigitalOutputHighState = 0x2c0003
    uidSetDigitalOutputLowState = 0x2c0004
    uidGetDigitalIOInfo = 0x2c0005
    uidGetAllDigitalIOInfo = 0x2c0006
    uidSetAnalogIOConfiguration = 0x2c0007
    uidGetAnalogIOConfiguration = 0x2c0008
    uidSetAnalogValue = 0x2c0009
    uidGetAnalogIOInfo = 0x2c000a
    uidGetAllAnalogIOInfo = 0x2c000b
    uidClearFaults = 0x2c000c
    uidGetRS485Configuration = 0x2c000d
    uidSetRS485Configuration = 0x2c000e
    uidGetPowerSupply24VState = 0x2c000f
    uidSetPowerSupply24VState = 0x2c0010
    uidGetArmSerialNumber = 0x2c0011



class WristConfigC61Client():
    
    serviceVersion = 1
    serviceId = 44

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a WristConfigC61Client with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetDigitalIOConfiguration(self, digitalioconfiguration: IndustrialIOPb.DigitalIOConfiguration, deviceId: int, options = RouterClientSendOptions()) :
        """
        Configures a digital I/O channel.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The channel.identifier parameter must be between 1 and 8.
        Filling the input_configuration parameter will set the pin as input and filling the output_configuration parameter will set the pin as output.
        
        """
        reqPayload = digitalioconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetDigitalIOConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDigitalIOConfiguration(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalIOConfiguration :
        """
        Retrieves a digital I/O configuration for a specific channel.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be between 1 and 8.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidGetDigitalIOConfiguration, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.DigitalIOConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetDigitalOutputHighState(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) :
        """
        Sets a digital output channel to a high state.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be between 1 and 8.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetDigitalOutputHighState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetDigitalOutputLowState(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) :
        """
        Sets a digital output channel to a low state.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be between 1 and 8.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetDigitalOutputLowState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDigitalIOInfo(self, digitalchannelidentifier: IndustrialIOPb.DigitalChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalIOInfo :
        """
        Retrieves a digital I/O channel information.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be between 1 and 8.
        
        """
        reqPayload = digitalchannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidGetDigitalIOInfo, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.DigitalIOInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllDigitalIOInfo(self, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.DigitalIOInfoList :
        """
        Retrieves all digital I/O channel information.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """


        future = self.router._send(None, self.serviceVersion, WristConfigC61FunctionUid.uidGetAllDigitalIOInfo, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.DigitalIOInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAnalogIOConfiguration(self, analogioconfiguration: IndustrialIOPb.AnalogIOConfiguration, deviceId: int, options = RouterClientSendOptions()) :
        """
        Configures a analog channel.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The channel.identifier parameter must be either ANALOG_CHANNEL_C or ANALOG_CHANNEL_D.
        
        """
        reqPayload = analogioconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetAnalogIOConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAnalogIOConfiguration(self, analogiochannelidentifier: IndustrialIOPb.AnalogIOChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOConfiguration :
        """
        Retrieves a analog input/output configuration for a specific channel.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be either ANALOG_CHANNEL_C or ANALOG_CHANNEL_D.
        
        """
        reqPayload = analogiochannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidGetAnalogIOConfiguration, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.AnalogIOConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAnalogValue(self, analogoutput: IndustrialIOPb.AnalogOutput, deviceId: int, options = RouterClientSendOptions()) :
        """
        Sets a analog value on a channel.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be either ANALOG_CHANNEL_C or ANALOG_CHANNEL_D.
        An UNSUPPORTED_ACTION error will be thrown when setting an analog value to a pin configured as input.
        Warning : sending a dac_value over the maximum value will cause a fault to be reported by the Wrist and power off the arm.
        
        """
        reqPayload = analogoutput.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetAnalogValue, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAnalogIOInfo(self, analogiochannelidentifier: IndustrialIOPb.AnalogIOChannelIdentifier, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOInfo :
        """
        Retrieves a analog input/output channel information.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The identifier parameter must be either ANALOG_CHANNEL_C or ANALOG_CHANNEL_D.
        
        """
        reqPayload = analogiochannelidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidGetAnalogIOInfo, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.AnalogIOInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllAnalogIOInfo(self, deviceId: int, options = RouterClientSendOptions()) -> IndustrialIOPb.AnalogIOInfoList :
        """
        Retrieves all analog input/output channels information.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """


        future = self.router._send(None, self.serviceVersion, WristConfigC61FunctionUid.uidGetAllAnalogIOInfo, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.AnalogIOInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ClearFaults(self, deviceId: int, options = RouterClientSendOptions()) :
        """
        Clears Digital and Analog I/O faults.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """


        future = self.router._send(None, self.serviceVersion, WristConfigC61FunctionUid.uidClearFaults, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetRS485Configuration(self, rs485deviceidentification: WristConfigPb.RS485DeviceIdentification, deviceId: int, options = RouterClientSendOptions()) -> WristConfigPb.RS485Configuration :
        """
        Retrieves RS485 configuration.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The port_id parameter must be set to RS485_PORT_FLANGE.
        
        """
        reqPayload = rs485deviceidentification.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidGetRS485Configuration, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.RS485Configuration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetRS485Configuration(self, rs485configuration: WristConfigPb.RS485Configuration, deviceId: int, options = RouterClientSendOptions()) :
        """
        Configures RS485.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        The port_id parameter must be set to RS485_PORT_FLANGE.
        
        """
        reqPayload = rs485configuration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetRS485Configuration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetPowerSupply24VState(self, deviceId: int, options = RouterClientSendOptions()) -> WristConfigPb.PowerSupply24VState :
        """
        Gets the power supply +24V state.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """


        future = self.router._send(None, self.serviceVersion, WristConfigC61FunctionUid.uidGetPowerSupply24VState, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.PowerSupply24VState()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetPowerSupply24VState(self, powersupply24vstate: WristConfigPb.PowerSupply24VState, deviceId: int, options = RouterClientSendOptions()) :
        """
        Sets the power supply +24V state.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """
        reqPayload = powersupply24vstate.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, WristConfigC61FunctionUid.uidSetPowerSupply24VState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetArmSerialNumber(self, deviceId: int, options = RouterClientSendOptions()) -> DeviceConfigPb.SerialNumber :
        """
        Gets the arm serial number.
        The arm must be powered on and the wrist's device identifier must be supplied as an input parameter.
        
        """


        future = self.router._send(None, self.serviceVersion, WristConfigC61FunctionUid.uidGetArmSerialNumber, deviceId, self.namespace, options)

        ansPayload = WristConfigC61Pb.SerialNumber()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

