
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ProgramConfig_pb2 as ProgramConfigPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ProgramConfigFunctionUid(Enum):
    uidCreateProgram = 0x220001
    uidDeleteProgram = 0x220002
    uidReadProgram = 0x220003
    uidReadAllPrograms = 0x220004
    uidUpdateProgram = 0x220005
    uidOnNotificationConfigurationChangeTopic = 0x220006
    uidUnsubscribe = 0x220007
    uidSetProgramOptions = 0x220008
    uidGetProgramOptions = 0x220009



class ProgramConfigClient():
    
    serviceVersion = 1
    serviceId = 34

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ProgramConfigClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


