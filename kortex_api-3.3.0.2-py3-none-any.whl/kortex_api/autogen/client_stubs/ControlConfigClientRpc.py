
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ControlConfig_pb2 as ControlConfigPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ControlConfigFunctionUid(Enum):
    uidSetGravityVector = 0x100001
    uidGetGravityVector = 0x100002
    uidSetPayloadInformation = 0x100003
    uidGetPayloadInformation = 0x100004
    uidSetToolConfiguration = 0x100005
    uidGetToolConfiguration = 0x100006
    uidOnNotificationControlConfigurationTopic = 0x100007
    uidUnsubscribe = 0x100008
    uidSetCartesianReferenceFrame = 0x100009
    uidGetCartesianReferenceFrame = 0x10000a
    uidSetLockedCartesianAxes = 0x10000b
    uidGetLockedCartesianAxes = 0x10000c
    uidGetControlMode = 0x10000d
    uidSetJointSpeedSoftLimits = 0x10000e
    uidSetTwistLinearSoftLimit = 0x10000f
    uidSetTwistAngularSoftLimit = 0x100010
    uidSetJointAccelerationSoftLimits = 0x100011
    uidGetKinematicHardLimits = 0x100012
    uidGetKinematicSoftLimits = 0x100013
    uidGetAllKinematicSoftLimits = 0x100014
    uidSetDesiredLinearTwist = 0x100015
    uidSetDesiredAngularTwist = 0x100016
    uidSetDesiredJointSpeeds = 0x100017
    uidGetDesiredSpeeds = 0x100018
    uidResetGravityVector = 0x100019
    uidResetPayloadInformation = 0x10001a
    uidResetToolConfiguration = 0x10001b
    uidResetJointSpeedSoftLimits = 0x10001c
    uidResetTwistLinearSoftLimit = 0x10001d
    uidResetTwistAngularSoftLimit = 0x10001e
    uidResetJointAccelerationSoftLimits = 0x10001f
    uidOnNotificationControlModeTopic = 0x100020
    uidSetJointPositionSoftLimits = 0x100021
    uidResetJointPositionSoftLimits = 0x100022
    uidGetSoftLimitsRange = 0x100023
    uidSetToolConfigurationList = 0x100024
    uidZeroExternalWrenchFromFTSensor = 0x100027
    uidResetExternalWrenchFromFTSensor = 0x100028
    uidSetTcpTranslationSpeedSaturation = 0x100029
    uidGetTcpTranslationSpeedSaturation = 0x10002a
    uidGetCollisionDetectionRangesList = 0x10002b
    uidSetAllCollisionDetectionLimits = 0x10002c
    uidGetAllCollisionDetectionLimits = 0x10002d
    uidGetEnergyLimitsRangesList = 0x10002e
    uidSetAllEnergyLimits = 0x10002f
    uidGetAllEnergyLimits = 0x100030
    uidOnNotificationArmSpeedFactorTopic = 0x100031
    uidSetArmSpeedFactor = 0x100032
    uidGetArmSpeedFactor = 0x100033



class ControlConfigClient():
    
    serviceVersion = 1
    serviceId = 16

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ControlConfigClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetGravityVector(self, gravityvector: ControlConfigPb.GravityVector, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets global gravity vector in terms of base reference frame.
        The arm must be powered off and not be in an Unrecoverable Fault state, or powered on and be in Monitored Stop state to set the gravity vector.
        This needs to be configured to enable control of the robot in wall or ceiling mounting.
        
        """
        reqPayload = gravityvector.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetGravityVector, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetGravityVector(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.GravityVector :
        """
        Retrieves global gravity vector
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetGravityVector, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.GravityVector()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetPayloadInformation(self, payloadinformation: ControlConfigPb.PayloadInformation, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets payload information.
        This needs to be configured so that the controller can take into account the presence of the payload while computing the kinematics of the robot.
        The arm must not be in an Unrecoverable Fault state to set the payload information.
        This RPC will also error with a WRONG_MODE error if a program is playing when it's called.
        
        """
        reqPayload = payloadinformation.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetPayloadInformation, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetPayloadInformation(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.PayloadInformation :
        """
        Retrieves payload information
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetPayloadInformation, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.PayloadInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetToolConfiguration(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.ToolConfiguration :
        """
        Retrieves the tool configuration
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetToolConfiguration, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.ToolConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationControlConfigurationTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidOnNotificationControlConfigurationTopic, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ControlConfigPb.ControlConfigurationNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ControlConfigFunctionUid.uidOnNotificationControlConfigurationTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving specified type of notifications
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def SetCartesianReferenceFrame(self, cartesianreferenceframeinfo: ControlConfigPb.CartesianReferenceFrameInfo, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Defines the reference frame to use with twist commands
        The arm must be powered on to set the reference frame.
        
        """
        reqPayload = cartesianreferenceframeinfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetCartesianReferenceFrame, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetCartesianReferenceFrame(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.CartesianReferenceFrameInfo :
        """
        Retrieves the current reference frame used by the twist commands
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetCartesianReferenceFrame, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.CartesianReferenceFrameInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetLockedCartesianAxes(self, axislockconfig: ControlConfigPb.AxisLockConfig, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Apply or remove a lock on some axis.
        control_mode must be CARTESIAN_HAND_GUIDING.
        translation.reference_frame must be CARTESIAN_REFERENCE_FRAME_TOOL or CARTESIAN_REFERENCE_FRAME_BASE.
        orientation.reference_frame must be CARTESIAN_REFERENCE_FRAME_TOOL or CARTESIAN_REFERENCE_FRAME_BASE.
        Both the translation and the orientation reference frames must be supplied and valid.
        translation.axes must contain 0 to 3 vectors. If more than one vector is provided, they must all be perpendicular.
        orientation.axes must contain 0 to 3 vectors. If more than one vector is provided, they must all be perpendicular.
        
        """
        reqPayload = axislockconfig.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetLockedCartesianAxes, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetLockedCartesianAxes(self, controlmodeinformation: ControlConfigPb.ControlModeInformation, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.AxisLockConfig :
        """
        Retrieves the locked axis status.
        control_mode must be CARTESIAN_HAND_GUIDING.
        
        """
        reqPayload = controlmodeinformation.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidGetLockedCartesianAxes, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.AxisLockConfig()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetControlMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.ControlModeInformation :
        """
        Retrieves current control mode
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetControlMode, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.ControlModeInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetKinematicHardLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.KinematicLimits :
        """
        Retrieves angular and twist hard limits.
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetKinematicHardLimits, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.KinematicLimits()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetDesiredLinearTwist(self, lineartwist: ControlConfigPb.LinearTwist, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the desired linear twist when jogging the robot
        A VALUE_ABOVE_MAXIMUM error will be raised if the twist value is above 1.6 m/s.
        
        """
        reqPayload = lineartwist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetDesiredLinearTwist, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetDesiredAngularTwist(self, angulartwist: ControlConfigPb.AngularTwist, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the desired angular twist when jogging the robot
        A VALUE_ABOVE_MAXIMUM error will be raised if the twist value is above 142.5 deg/s.
        
        """
        reqPayload = angulartwist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetDesiredAngularTwist, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetDesiredJointSpeeds(self, jointspeeds: ControlConfigPb.JointSpeeds, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the desired joint speeds when jogging in angular mode.
        A VALUE_ABOVE_MAXIMUM error will be raised if any of the joint speeds is above its limit.
        The size of the joint_speed parameter must be equal to the number of actuators.
        
        """
        reqPayload = jointspeeds.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetDesiredJointSpeeds, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetDesiredSpeeds(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.DesiredSpeeds :
        """
        Retrieves the desired joystick speeds
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetDesiredSpeeds, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.DesiredSpeeds()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ResetGravityVector(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.GravityVector :
        """
        Resets gravity vector to default values.
        The arm must be powered off and not be in an Unrecoverable Fault state, or powered on and be in Monitored Stop state to set the gravity vector.
        The default values are (x = 0, y = 0, z = -9.81).
        
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidResetGravityVector, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.GravityVector()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ResetPayloadInformation(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.PayloadInformation :
        """
        Resets payload information to default values.
        This needs to be configured so that the controller can take into account the presence of the payload in computing the dynamics of the robot.
        The arm must not be in an Unrecoverable Fault state to set the payload information.
        This RPC will also error with a WRONG_MODE error if a program is playing when it's called.
        
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidResetPayloadInformation, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.PayloadInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationControlModeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidOnNotificationControlModeTopic, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ControlConfigPb.ControlModeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ControlConfigFunctionUid.uidOnNotificationControlModeTopic, self.namespace, notifCallback)
        return ansPayload

    def ZeroExternalWrenchFromFTSensor(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Adds a persistent offset to the force torque sensor measurements of external efforts to make them equal to zero.
        This allows to compensate for small measurement errors (for example drift due to temperature).
        The arm must be powered on to set the zero external wrench.
        
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidZeroExternalWrenchFromFTSensor, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ResetExternalWrenchFromFTSensor(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Resets external wrench from force torque sensor.
        The arm must be powered on to set the zero external wrench.
        
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidResetExternalWrenchFromFTSensor, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    @deprecated("Replaced by GetArmSpeedFactor")
    def GetTcpTranslationSpeedSaturation(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.LinearTwist :
        """
        Gets the tcp translation speed saturation
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetTcpTranslationSpeedSaturation, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.LinearTwist()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetCollisionDetectionRangesList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.CollisionDetectionRangesList :
        """
        Retrieves collision detection limits range
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetCollisionDetectionRangesList, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.CollisionDetectionRangesList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAllCollisionDetectionLimits(self, collisiondetectionlimitslist: ControlConfigPb.CollisionDetectionLimitsList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all collision detection limits and activation mode statuses.
        The arm must be powered off and not be in an Unrecoverable Fault state, or powered on and be in Monitored Stop state to set the limits.
        
        """
        reqPayload = collisiondetectionlimitslist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetAllCollisionDetectionLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAllCollisionDetectionLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.CollisionDetectionLimitsList :
        """
        Gets all collision detection limits and activation mode statuses
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetAllCollisionDetectionLimits, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.CollisionDetectionLimitsList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetEnergyLimitsRangesList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.EnergyLimitsRangesList :
        """
        Retrieves energy limitation ranges
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetEnergyLimitsRangesList, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.EnergyLimitsRangesList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetAllEnergyLimits(self, energylimitslist: ControlConfigPb.EnergyLimitsList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all energy limits and activation mode statuses.
        The arm must be powered off and not be in an Unrecoverable Fault state, or powered on and be in Monitored Stop state to set the limits.
        
        """
        reqPayload = energylimitslist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetAllEnergyLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAllEnergyLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.EnergyLimitsList :
        """
        Gets all energy limits and activation mode statuses
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetAllEnergyLimits, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.EnergyLimitsList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationArmSpeedFactorTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidOnNotificationArmSpeedFactorTopic, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ControlConfigPb.ArmSpeedFactorNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ControlConfigFunctionUid.uidOnNotificationArmSpeedFactorTopic, self.namespace, notifCallback)
        return ansPayload

    def SetArmSpeedFactor(self, desiredarmspeedfactor: ControlConfigPb.DesiredArmSpeedFactor, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the arm speed factor
        """
        reqPayload = desiredarmspeedfactor.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ControlConfigFunctionUid.uidSetArmSpeedFactor, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetArmSpeedFactor(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ControlConfigPb.DesiredArmSpeedFactor :
        """
        Gets the arm speed factor
        """


        future = self.router._send(None, self.serviceVersion, ControlConfigFunctionUid.uidGetArmSpeedFactor, deviceId, self.namespace, options)

        ansPayload = ControlConfigPb.DesiredArmSpeedFactor()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

