
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import DeviceManager_pb2 as DeviceManagerPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class DeviceManagerFunctionUid(Enum):
    uidReadAllDevices = 0x170001



class DeviceManagerClient():
    
    serviceVersion = 1
    serviceId = 23

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a DeviceManagerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def ReadAllDevices(self, deviceId: int = 0, options = RouterClientSendOptions()) -> DeviceManagerPb.DeviceHandles :
        """
        Retrieves the list of every device that the system contains, along with its type and order within the system
        """


        future = self.router._send(None, self.serviceVersion, DeviceManagerFunctionUid.uidReadAllDevices, deviceId, self.namespace, options)

        ansPayload = DeviceManagerPb.DeviceHandles()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

