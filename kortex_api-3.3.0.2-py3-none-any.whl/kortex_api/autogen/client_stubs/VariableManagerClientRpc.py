
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import VariableManager_pb2 as VariableManagerPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class VariableManagerFunctionUid(Enum):
    uidSetVariable = 0x280001
    uidGetVariable = 0x280002
    uidDeleteVariable = 0x280003
    uidGetAllVariables = 0x280004
    uidGetAllNamespaces = 0x280005
    uidDeleteNamespace = 0x280006
    uidGetAllVariableJsonSchemas = 0x280007
    uidOnNotificationVariableChangeTopic = 0x280008
    uidUnsubscribe = 0x280009
    uidInterpolate = 0x28000a
    uidOnNotificationVariableJsonSchemasChangedTopic = 0x28000b
    uidCreateNamespace = 0x28000c



class VariableManagerClient():
    
    serviceVersion = 1
    serviceId = 40

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a VariableManagerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetVariable(self, variable: VariableManagerPb.Variable, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.VariableHandle :
        """
        Modifies or adds a variable.
        
        An INVALID_PARAM exception is thrown if the variable or namespace identifiers contain anything else than a-Z, 0-9 and _.
        A METHOD_FAILED exception is thrown if the variable to set is a system variable.
        
        """
        reqPayload = variable.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidSetVariable, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.VariableHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetVariable(self, variablehandle: VariableManagerPb.VariableHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.Variable :
        """
        Gets a variable.
        
        An ENTITY_NOT_FOUND exception is thrown if the variable does not exist.
        
        """
        reqPayload = variablehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidGetVariable, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.Variable()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteVariable(self, variablehandle: VariableManagerPb.VariableHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes a variable.
        To be deleted, the variable must exist and not contain flags.
        
        An ENTITY_NOT_FOUND exception is thrown if the variable does not exist.
        A METHOD_FAILED exception is thrown if the variable to set is a system variable.
        
        """
        reqPayload = variablehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidDeleteVariable, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAllVariables(self, namespacehandle: VariableManagerPb.NamespaceHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.NamespaceVariables :
        """
        Get all variables. Optionally, a namespace can be specified.
        """
        reqPayload = namespacehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidGetAllVariables, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.NamespaceVariables()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllNamespaces(self, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.Namespaces :
        """
        Get all namespaces.
        """


        future = self.router._send(None, self.serviceVersion, VariableManagerFunctionUid.uidGetAllNamespaces, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.Namespaces()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteNamespace(self, namespacehandle: VariableManagerPb.NamespaceHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes a namespace.
        """
        reqPayload = namespacehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidDeleteNamespace, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetAllVariableJsonSchemas(self, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.VariableJsonSchemaList :
        """
        Get all variable JSON schemas available on robot (base & plugin schemas).
        """


        future = self.router._send(None, self.serviceVersion, VariableManagerFunctionUid.uidGetAllVariableJsonSchemas, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.VariableJsonSchemaList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationVariableChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidOnNotificationVariableChangeTopic, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = VariableManagerPb.ConfigurationChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(VariableManagerFunctionUid.uidOnNotificationVariableChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic.
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def Interpolate(self, interpolatestring: VariableManagerPb.InterpolateString, deviceId: int = 0, options = RouterClientSendOptions()) -> VariableManagerPb.InterpolateString :
        """
        Interpolate variables in a string.
        
        An INVALID_PARAM exception is thrown if the input is not json-parsable.
        An ERROR_DEVICE exception is thrown if the interpolation fails (ex. a variable does not exist).
        
        """
        reqPayload = interpolatestring.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidInterpolate, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.InterpolateString()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationVariableJsonSchemasChangedTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidOnNotificationVariableJsonSchemasChangedTopic, deviceId, self.namespace, options)

        ansPayload = VariableManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = VariableManagerPb.VariableJsonSchemasChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(VariableManagerFunctionUid.uidOnNotificationVariableJsonSchemasChangedTopic, self.namespace, notifCallback)
        return ansPayload

    def CreateNamespace(self, namespacehandle: VariableManagerPb.NamespaceHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Creates a namespace.
        """
        reqPayload = namespacehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, VariableManagerFunctionUid.uidCreateNamespace, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





