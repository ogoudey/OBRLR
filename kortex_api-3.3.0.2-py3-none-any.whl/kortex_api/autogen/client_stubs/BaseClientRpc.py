
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import Base_pb2 as BasePb  # NOQA
from ..messages import ProductConfiguration_pb2 as ProductConfigurationPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class BaseFunctionUid(Enum):
    uidCreateUserProfile = 0x20001
    uidUpdateUserProfile = 0x20002
    uidReadUserProfile = 0x20003
    uidDeleteUserProfile = 0x20004
    uidReadAllUserProfiles = 0x20005
    uidReadAllUsers = 0x20006
    uidChangePassword = 0x20007
    uidCreateAction = 0x2002a
    uidReadAction = 0x2002b
    uidReadAllActions = 0x2002c
    uidDeleteAction = 0x2002d
    uidUpdateAction = 0x2002e
    uidExecuteAction = 0x20030
    uidPauseAction = 0x20031
    uidStopAction = 0x20032
    uidResumeAction = 0x20033
    uidGetIPv4Configuration = 0x2003b
    uidSetIPv4Configuration = 0x2003c
    uidUnsubscribe = 0x20061
    uidOnNotificationConfigurationChangeTopic = 0x20062
    uidOnNotificationOperatingModeTopic = 0x20065
    uidOnNotificationControllerTopic = 0x20069
    uidOnNotificationActionTopic = 0x2006a
    uidOnNotificationRobotEventTopic = 0x2006b
    uidStop = 0x20070
    uidGetMeasuredCartesianPose = 0x20073
    uidSendTwistJoystickCommand = 0x20078
    uidSendTwistCommand = 0x20079
    uidGetMeasuredJointAngles = 0x2007e
    uidSendJointSpeedsCommand = 0x20084
    uidSendSelectedJointSpeedCommand = 0x20085
    uidApplyQuickStop = 0x20091
    uidClearFaults = 0x20092
    uidSetServoingMode = 0x20098
    uidGetServoingMode = 0x20099
    uidOnNotificationServoingModeTopic = 0x2009a
    uidRestoreFactorySettings = 0x200a0
    uidReboot = 0x200a2
    uidOnNotificationFactoryTopic = 0x200a4
    uidGetActuatorCount = 0x200ab
    uidGetArmState = 0x200af
    uidOnNotificationArmStateTopic = 0x200b0
    uidGetIPv4Information = 0x200b1
    uidSendJointSpeedsJoystickCommand = 0x200bb
    uidSendSelectedJointSpeedJoystickCommand = 0x200bc
    uidGetProductConfiguration = 0x200c6
    uidRestoreFactoryProductConfiguration = 0x200ce
    uidGetTrajectoryErrorReport = 0x200cf
    uidGetFirmwareBundleVersions = 0x200e0
    uidExecuteWaypointTrajectory = 0x200e2
    uidValidateWaypointList = 0x200ec
    uidComputeForwardKinematics = 0x200ed
    uidComputeInverseKinematics = 0x200ee
    uidActivateRobot = 0x200ef
    uidOnNotificationUpdatingModeTopic = 0x200f0
    uidSetUpdatingMode = 0x200f1
    uidGetUpdatingMode = 0x200f2
    uidSelectOperatingMode = 0x200f3
    uidExitRecoveryState = 0x200f4
    uidDeactivateRobot = 0x200f5
    uidGetCurrentOperatingMode = 0x200f6
    uidReadAllUserRoles = 0x200f7
    uidSetHandGuidingMode = 0x200f8
    uidGetHandGuidingMode = 0x200f9
    uidOnNotificationHandGuidingModeTopic = 0x200fa
    uidGetLocalUpdateFileList = 0x200fb
    uidOnNotificationEnablingDeviceTopic = 0x200fc
    uidConfirmArmPosition = 0x200fd
    uidOnNotificationMotionTopic = 0x200fe
    uidGetLastRecordedJointAngles = 0x200ff
    uidOnNotificationProgramRequestTopic = 0x20100
    uidGetStorageList = 0x20101
    uidFileSystemList = 0x20102
    uidFileWrite = 0x20103
    uidFileRead = 0x20104
    uidGetRemoteAccessInfoList = 0x20105
    uidEnableRemoteAccess = 0x20106
    uidDisableRemoteAccess = 0x20107
    uidOnNotificationRemoteAccessChangeTopic = 0x20108
    uidImportArmCalibration = 0x20109
    uidExportArmCalibration = 0x2010a
    uidRestoreNeutralArmCalibration = 0x2010b
    uidGetArmCalibrationStatus = 0x2010c
    uidOnNotificationArmCalibrationStatusChangeTopic = 0x2010d
    uidOnNotificationAcknowledgeActionTopic = 0x2010e



class BaseClient():
    
    serviceVersion = 1
    serviceId = 2

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a BaseClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def CreateUserProfile(self, fulluserprofile: BasePb.FullUserProfile, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.UserProfileHandle :
        """
        Creates a user profile and returns a handle to the profile.
        The created user profile will always have the "Operator" role, who has the READ_ONLY and OPERATE user permissions.
        The handle.permission field is a bitmask of Common.Permission values. A permission of 7 should always be used.
        The username cannot be empty.
        The username, first name and last name cannot exceed 50 characters in length.
        The password cannot exceed 103 characters in length.
        There cannot be more than 107 user profiles created.
        Two user profiles cannot have the same username.
        
        """
        reqPayload = fulluserprofile.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidCreateUserProfile, deviceId, self.namespace, options)

        ansPayload = BasePb.UserProfileHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def UpdateUserProfile(self, userprofile: BasePb.UserProfile, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Updates an existing user profile.
        The handle.identifier parameter must be set to a valid identifier.
        The username cannot already be in use by another user profile.
        The same username, password, first name and last name length constraints as CreateUserProfile apply for this RPC.
        
        """
        reqPayload = userprofile.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidUpdateUserProfile, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ReadUserProfile(self, userprofilehandle: CommonPb.UserProfileHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.UserProfile :
        """
        Retrieves an existing user profile
        """
        reqPayload = userprofilehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidReadUserProfile, deviceId, self.namespace, options)

        ansPayload = BasePb.UserProfile()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteUserProfile(self, userprofilehandle: CommonPb.UserProfileHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes an existing user profile.
        The handle.identifier parameter must be set to a valid identifier.
        The handle.permission of the user profile to delete must include the DELETE_PERMISSION.
        
        """
        reqPayload = userprofilehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidDeleteUserProfile, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ReadAllUserProfiles(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.UserProfileList :
        """
        Retrieves all user profiles
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidReadAllUserProfiles, deviceId, self.namespace, options)

        ansPayload = BasePb.UserProfileList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadAllUsers(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.UserList :
        """
        Retrieves the list of all user profile handles
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidReadAllUsers, deviceId, self.namespace, options)

        ansPayload = BasePb.UserList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ChangePassword(self, passwordchange: BasePb.PasswordChange, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Changes the password of an existing user.
        The handle.identifier parameter must be set to a valid identifier.
        The old_password parameter must match the user's current password.
        
        """
        reqPayload = passwordchange.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidChangePassword, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ExecuteAction(self, action: BasePb.Action, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Commands the robot to execute the specified action.
        This RPC cannot be called when the operating mode is OPERATING_MODE_JOG_MANUAL.
        This RPC will be ignored if it is called when the operating mode is OPERATING_MODE_MONITORED_STOP.
        A ROBOT_NOT_MOVING exception "Failed to execute action: The Enabling device must be pressed for the arm to move" is thrown if the operating mode is OPERATING_MODE_HOLD_TO_RUN and the enabling device is not pressed when the action starts running.
        A DEVICE_DISCONNECTED exception "Stopping motion failed for Session ID <session ID>: No Arm Detected" is thrown if the arm is not powered on.
        Most of the action types are no longer supported. All action types that are not detailed below will return an UNSUPPORTED_ACTION exception "Unsupported action type: <type ID of action> in action "<name of action>"".
        
        send_twist_command:
        - If the input twist is higher than the set arm limits, the command does not return an error or warning but the twists do not exceed the set limits.
        - If the arm is given a twist command in a direction it can't move in, it will try to move which can induce movement in other directions as well.
        - If the twist is too high, the induced acceleration may cause the arm to falsely detect a collision.
        - The action will not stop after the time specified in the duration parameter of the TwistCommand object.
        
        send_joint_speeds:
        - The JointSpeed objects' input parameter "identifier" should be an integer between 0 and 5, defining the index of the joint to control.
        - If not all 6 joint speeds have been defined, then the undefined ones are set as 0.
        
        execute_waypoint_list:has to be an integer
        - A METHOD_FAILED exception "The waypoint list is empty" will be thrown if the list of waypoints is empty or no argument has been passed to the WaypointList object.
        - If a waypoint is out of reach, the robot will not execute the waypoint list and it will send a warning message "Invalid Waypoint - Out of Robot Workspace".
        - The action will not stop after the time specified in the duration parameter of the WaypointList object.
        - When the list of waypoints contains AngularWaypoint, an ACTION_FEEDBACK notification is sent on the Action Topic for each waypoint: when the joint angle targets are reached (without blending), or when the joint angles are close to the target (with blending).
        - When the list of waypoints contains CartesianWaypoint, an ACTION_FEEDBACK notification is sent on the Action Topic for each waypoint: when the translation goal is reached (without blending), or when the path is the closest to the translation goal (with blending).
        - When the list of waypoints contains Toolpath waypoints, an ACTION_FEEDBACK notification is sent on the Action Topic for each waypoint: when the translation goal is reached (StraightSegmentToolpath without blending or ArcPointToolpath without blending), after the translation arc (StraightSegmentToolpath with blending, ArcPointToolpath with blending or ArcRadiusToolpath).
        
        change_payload_parameters:
        - The input parameter mass of ChangePayloadParameters has to be between 0 and 9 kg.
        - The input parameter center_of_mass should have values between -1 and 1.
        - The input parameter inertia should have diagonal values (I :sub:`xx`,I :sub:`yy`,I :sub:`zz`) between 0 and 1, and cross-product element values (I :sub:`xy`,I :sub:`xz`,I :sub:`yz`) between -1 and 1.
        - If any value is outside its range, the action will be ignored and no value will be changed.
        
        switch_control_mapping:
        - This action type is not to be used.
        
        execute_action:
        - This action type is deprecated.
        
        """
        reqPayload = action.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidExecuteAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def PauseAction(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Pauses the currently executed action. ResumeAction can be invoked afterwards.
        Pausing an action sets the operating the operating mode to OPERATING_MODE_MONITORED_STOP.
        A ROBOT_NOT_MOVING exception "Failed to pause action: The Enabling device must be pressed for the arm to move" is thrown when the operating mode is OPERATING_MODE_HOLD_TO_RUN and the enabling device is not pressed.
        A DEVICE_DISCONNECTED exception "Failed to pause action: No Arm Detected" is thrown if the arm is not powered on.
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidPauseAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def StopAction(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Stops robot movement
        """
        """
        Stops the currently executed action. ResumeAction cannot be invoked afterwards.
        An INVALID_PARAM exception "Failed to stop action: Argument Invalid" is thrown if the operating mode is OPERATING_MODE_MONITORED_STOP.
        A ROBOT_NOT_MOVING exception "Failed to stop action: The Enabling device must be pressed for the arm to move" is thrown when the operating mode is OPERATING_MODE_HOLD_TO_RUN and the enabling device is not pressed.
        A ROBOT_NOT_MOVING exception "Failed to stop action: Trying to stop, pause or resume an action that is not started" is thrown if no action is started before the RPC is called.
        A DEVICE_DISCONNECTED exception "Failed to stop action: No Arm Detected" is thrown if the arm is not powered on.
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidStopAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ResumeAction(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Resumes execution of the currently paused action.
        This RPC can only be called when the operating mode is OPERATING_MODE_AUTO.
        An INVALID_PARAM exception "Failed to resume action: Argument Invalid" is thrown if the operating mode is OPERATING_MODE_MONITORED_STOP.
        A METHOD_FAILED exception "Failed to resume action: Action failed" is thrown if the operating mode is OPERATING_MODE_HOLD_TO_RUN.
        A DEVICE_DISCONNECTED exception "Failed to resume action: No Arm Detected" is thrown if the arm is not powered on.
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidResumeAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetIPv4Configuration(self, networkhandle: BasePb.NetworkHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.IPv4Configuration :
        """
        Retrieves the IPv4 network configuration for the specified network adapter
        """
        reqPayload = networkhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidGetIPv4Configuration, deviceId, self.namespace, options)

        ansPayload = BasePb.IPv4Configuration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def OnNotificationConfigurationChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationConfigurationChangeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ConfigurationChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationConfigurationChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationOperatingModeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationOperatingModeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.OperatingModeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationOperatingModeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationControllerTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationControllerTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ControllerNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationControllerTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationActionTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationActionTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ActionNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationActionTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationRobotEventTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationRobotEventTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.RobotEventNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationRobotEventTopic, self.namespace, notifCallback)
        return ansPayload

    def Stop(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Stops robot movement
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidStop, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetMeasuredCartesianPose(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.Pose :
        """
        Retrieves the current computed tool pose (position and orientation) for the robot
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetMeasuredCartesianPose, deviceId, self.namespace, options)

        ansPayload = BasePb.Pose()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SendTwistJoystickCommand(self, twistcommand: BasePb.TwistCommand, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends a twist (screw consisting of linear and angular velocity) joystick command to be applied to the tool.
        The twist values sent to this call are expected to be a ratio of the maximum value (between -1.0/+1.0).
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = twistcommand.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendTwistJoystickCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SendTwistCommand(self, twistcommand: BasePb.TwistCommand, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends a twist (screw consisting of linear and angular velocity) command to be applied to the tool.
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = twistcommand.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendTwistCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetMeasuredJointAngles(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.JointAngles :
        """
        Retrieves the currently measured joint angles for each joint
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetMeasuredJointAngles, deviceId, self.namespace, options)

        ansPayload = BasePb.JointAngles()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SendJointSpeedsCommand(self, jointspeeds: BasePb.JointSpeeds, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends a set of joint speed commands to all joints with one command. Joint speed commmands must be sent to all joints.
        If you do not want to move some of the joints, simply send a speed value of 0 degrees / second for that joint.
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = jointspeeds.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendJointSpeedsCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SendSelectedJointSpeedCommand(self, jointspeed: BasePb.JointSpeed, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends a speed command for a specific joint.
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = jointspeed.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendSelectedJointSpeedCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ApplyQuickStop(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Applies a category 2 stop to the robot and puts it back in Monitored Stop state.
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidApplyQuickStop, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ClearFaults(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Clears robot fault state. Robot is permitted to move again.
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidClearFaults, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetServoingMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.ServoingModeInformation :
        """
        Retrieves current servoing mode
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetServoingMode, deviceId, self.namespace, options)

        ansPayload = BasePb.ServoingModeInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationServoingModeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationServoingModeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ServoingModeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationServoingModeTopic, self.namespace, notifCallback)
        return ansPayload

    def RestoreFactorySettings(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes all configurations and reverts settings to their factory defaults (except network settings)
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidRestoreFactorySettings, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Reboot(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Reboots the controller
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidReboot, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationFactoryTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationFactoryTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.FactoryNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationFactoryTopic, self.namespace, notifCallback)
        return ansPayload

    def GetActuatorCount(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.ActuatorInformation :
        """
        Retrieves the number of actuators in the robot
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetActuatorCount, deviceId, self.namespace, options)

        ansPayload = BasePb.ActuatorInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetArmState(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.ArmStateInformation :
        """
        Retrieves current robot arm state
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetArmState, deviceId, self.namespace, options)

        ansPayload = BasePb.ArmStateInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationArmStateTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationArmStateTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ArmStateNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationArmStateTopic, self.namespace, notifCallback)
        return ansPayload

    def GetIPv4Information(self, networkhandle: BasePb.NetworkHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.IPv4Information :
        """
        Retrieves the IPv4 network information for the specified network adapter
        """
        reqPayload = networkhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidGetIPv4Information, deviceId, self.namespace, options)

        ansPayload = BasePb.IPv4Information()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SendJointSpeedsJoystickCommand(self, jointspeeds: BasePb.JointSpeeds, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends the desired joystick speeds to all joints with one command.
        The speed values sent to this call are expected to be a ratio of the maximum value (between -1.0/+1.0)
        Speeds must be sent to all joints. If you don't want to move some of the joints, send a value of 0.
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = jointspeeds.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendJointSpeedsJoystickCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SendSelectedJointSpeedJoystickCommand(self, jointspeed: BasePb.JointSpeed, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sends a joystick speed for a specific joint.
        The speed value sent to this call is expected to be a ratio of the maximum value (between -1.0/+1.0)
        This RPC can only be sent while the robot is in Jog Manual.
        A ROBOT_NOT_MOVING error will be thrown if the Enabling Device is not pressed.
        
        """
        reqPayload = jointspeed.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSendSelectedJointSpeedJoystickCommand, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetProductConfiguration(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ProductConfigurationPb.CompleteProductConfiguration :
        """
        Retrieves product configuration information
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetProductConfiguration, deviceId, self.namespace, options)

        ansPayload = BasePb.CompleteProductConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetTrajectoryErrorReport(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.TrajectoryErrorReport :
        """
        Obtains trajectory error report listing errors for rejected trajectory.
        Provides some feedback on why the trajectory could not be completed.
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetTrajectoryErrorReport, deviceId, self.namespace, options)

        ansPayload = BasePb.TrajectoryErrorReport()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetFirmwareBundleVersions(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.FirmwareBundleVersions :
        """
        Retrieves current firmware bundle versions
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetFirmwareBundleVersions, deviceId, self.namespace, options)

        ansPayload = BasePb.FirmwareBundleVersions()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ExecuteWaypointTrajectory(self, waypointlist: BasePb.WaypointList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Executes a trajectory defined by a series of waypoints in joint space or in Cartesian space
        """
        reqPayload = waypointlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidExecuteWaypointTrajectory, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ValidateWaypointList(self, waypointlist: BasePb.WaypointList, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.WaypointValidationReport :
        """
        Validate a waypoint list, returns an empty trajectory error report list if the waypoint list is valid.
        If the use_optimal_blending option is true, a waypoint list with optimal blending will be returned.
        
        """
        reqPayload = waypointlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidValidateWaypointList, deviceId, self.namespace, options)

        ansPayload = BasePb.WaypointValidationReport()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ComputeForwardKinematics(self, jointangles: BasePb.JointAngles, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.Pose :
        """
        Get the forward kinematics given specified angular positions of actuators
        """
        reqPayload = jointangles.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidComputeForwardKinematics, deviceId, self.namespace, options)

        ansPayload = BasePb.Pose()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ComputeInverseKinematics(self, ikdata: BasePb.IKData, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.JointAngles :
        """
        Get the inverse kinematics given a specified cartesian pose and guess of joint angles
        """
        reqPayload = ikdata.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidComputeInverseKinematics, deviceId, self.namespace, options)

        ansPayload = BasePb.JointAngles()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ActivateRobot(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Activates the robot.
        This function will return after the command is sent, not after the arm is properly activated.
        Subscribe to the ArmStateTopic to be notified of the robot's current activation status.
        A METHOD_FAILED error will be thrown if the robot was powered off less than 8 seconds ago. Activating the robot can only be done more than 8 seconds after the last power off.
        A WRONG_MODE error will be thrown if the robot is already activated.
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidActivateRobot, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationUpdatingModeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationUpdatingModeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.UpdatingModeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationUpdatingModeTopic, self.namespace, notifCallback)
        return ansPayload

    @deprecated("This RPC was replaced by UpgradeSWU located in SoftwareUpdate service.")
    def SetUpdatingMode(self, updatingmodeinformation: BasePb.UpdatingModeInformation, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a new updating mode. Only Maintenance, Update and Run modes are permitted.
        This RPC will throw an UNSUPPORTED_METHOD exception if called.
        """
        reqPayload = updatingmodeinformation.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSetUpdatingMode, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetUpdatingMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.UpdatingModeInformation :
        """
        Retrieves current updating mode
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetUpdatingMode, deviceId, self.namespace, options)

        ansPayload = BasePb.UpdatingModeInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SelectOperatingMode(self, modeselection: CommonPb.ModeSelection, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Select the operating mode
        There is a small transition period (about 1 ms) when switching operating modes where the value of the current operating mode is temporarily set as OPERATING_MODE_MONITORED_STOP.
        If a call that checks the current operating mode is made from the API shortly after this RPC has been called, it might return OPERATING_MODE_MONITORED_STOP instead of the correct operating mode.
        
        When the arm is in ARMSTATE_RECOVERY, no exceptions are thrown but the command is ignored
        
        A DEVICE_DISCONNECTED exception "Stopping motion failed for Session ID <session ID>: No Arm Detected" will be thrown if the arm is powered off.
        A ROBOT_NOT_READY exception "Stopping motion failed for Session ID <session ID>: Arm Initialization In Progress" if the arm is initializing.
        A METHOD_FAILED exception "Failed to change the operating mode : Unknown Event" if the arm is in fault (either powered on or off).
        A WRONG_MODE exception "Failed to change the operating mode : Invalid operating mode" will be thrown if the parameter is OPERATING_MODE_HAND_GUIDING.
        A WRONG_MODE exception "Failed to change the operating mode : Invalid transition between two operating modes" will be thrown if the parameter is not an admissible mode to transition into from the current operating mode.
        
        From the operating mode OPERATING_MODE_MONITORED_STOP, the admissible transitions are to the operating modes:
        - OPERATING_MODE_MONITORED_STOP
        - OPERATING_MODE_HOLD_TO_RUN
        - OPERATING_MODE_AUTO
        - OPERATING_MODE_JOG_MANUAL
        
        From the operating mode OPERATING_MODE_HOLD_TO_RUN, the admissible transitions are to the operating modes:
        - OPERATING_MODE_MONITORED_STOP
        - OPERATING_MODE_AUTO
        - OPERATING_MODE_JOG_MANUAL
        
        From the operating mode OPERATING_MODE_AUTO, the admissible transitions are to the operating modes:
        - OPERATING_MODE_MONITORED_STOP
        - OPERATING_MODE_HOLD_TO_RUN
        
        From the operating mode OPERATING_MODE_JOG_MANUAL, the admissible transitions are to the operating modes:
        - OPERATING_MODE_MONITORED_STOP
        - OPERATING_MODE_HOLD_TO_RUN
        - OPERATING_MODE_JOG_MANUAL
        
        
        """
        reqPayload = modeselection.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSelectOperatingMode, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ExitRecoveryState(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Exit the recovery state after clearing a fault
        This RPC should be called when the Arm State is ARMSTATE_RECOVERY.
        A WRONG_MODE exception "Arm is not in recovery mode" is thrown if the arm is not in recovery mode
        A METHOD_FAILED exception "Arm is still in restricted area - can't exit recovery mode" will be thrown if the arm is not out of the protection zone when the RPC is called
        
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidExitRecoveryState, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def DeactivateRobot(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deactivates the robot.
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidDeactivateRobot, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetCurrentOperatingMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.ModeSelection :
        """
        Retrieves the current robot operating mode
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetCurrentOperatingMode, deviceId, self.namespace, options)

        ansPayload = BasePb.ModeSelection()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadAllUserRoles(self, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.UserRoleList :
        """
        Retrieves the list of existing User Roles
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidReadAllUserRoles, deviceId, self.namespace, options)

        ansPayload = BasePb.UserRoleList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetHandGuidingMode(self, handguiding: BasePb.HandGuiding, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Set the Hand-Guiding
        This RPC can be called even if the arm is powered off
        An INVALID_PARAM exception "Invalid hand-guiding type" is thrown if the hand guiding mode is not CARTESIAN or JOINT.
        
        """
        reqPayload = handguiding.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidSetHandGuidingMode, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetHandGuidingMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.HandGuiding :
        """
        Get the Hand-Guiding mode that will be active while hand guiding
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetHandGuidingMode, deviceId, self.namespace, options)

        ansPayload = BasePb.HandGuiding()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationHandGuidingModeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationHandGuidingModeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.HandGuidingModeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationHandGuidingModeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationEnablingDeviceTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationEnablingDeviceTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.EnablingDeviceNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationEnablingDeviceTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationMotionTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationMotionTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.MotionNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationMotionTopic, self.namespace, notifCallback)
        return ansPayload

    def GetLastRecordedJointAngles(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.JointAngles :
        """
        Gets the last recorded joint angles
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetLastRecordedJointAngles, deviceId, self.namespace, options)

        ansPayload = BasePb.JointAngles()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationProgramRequestTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationProgramRequestTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ProgramRequestNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationProgramRequestTopic, self.namespace, notifCallback)
        return ansPayload

    @deprecated("This RPC was moved to Storage service.")
    def GetStorageList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.StorageMountPointList :
        """
        Get available storage mount points
        This RPC will throw an UNSUPPORTED_METHOD exception if called.
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetStorageList, deviceId, self.namespace, options)

        ansPayload = BasePb.StorageMountPointList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    @deprecated("This RPC was moved to Storage service and renamed to GetFileSystemList.")
    def FileSystemList(self, fslistargs: BasePb.FSListArgs, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.FSItemList :
        """
        Perform file system item list (files and directories) from given path.
        This RPC will throw an UNSUPPORTED_METHOD exception if called.
        """
        reqPayload = fslistargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidFileSystemList, deviceId, self.namespace, options)

        ansPayload = BasePb.FSItemList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    @deprecated("This RPC was moved to Storage service.")
    def FileWrite(self, fswriteargs: BasePb.FSWriteArgs, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Write text data to a file specified by given path. Directories are created if they do not exist.
        This RPC will throw an UNSUPPORTED_METHOD exception if called.
        """
        reqPayload = fswriteargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidFileWrite, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    @deprecated("This RPC was moved to Storage service.")
    def FileRead(self, fsreadargs: BasePb.FSReadArgs, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.FSReadData :
        """
        Read text data from file specified by given path.
        This RPC will throw an UNSUPPORTED_METHOD exception if called.
        """
        reqPayload = fsreadargs.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidFileRead, deviceId, self.namespace, options)

        ansPayload = BasePb.FSReadData()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def RestoreNeutralArmCalibration(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Restores arm calibration to neutral
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidRestoreNeutralArmCalibration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetArmCalibrationStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> BasePb.ArmCalibrationStatus :
        """
        Gets arm calibration status
        """


        future = self.router._send(None, self.serviceVersion, BaseFunctionUid.uidGetArmCalibrationStatus, deviceId, self.namespace, options)

        ansPayload = BasePb.ArmCalibrationStatus()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationArmCalibrationStatusChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationArmCalibrationStatusChangeTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.ArmCalibrationStatusChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationArmCalibrationStatusChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationAcknowledgeActionTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, BaseFunctionUid.uidOnNotificationAcknowledgeActionTopic, deviceId, self.namespace, options)

        ansPayload = BasePb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = BasePb.AcknowledgeActionNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(BaseFunctionUid.uidOnNotificationAcknowledgeActionTopic, self.namespace, notifCallback)
        return ansPayload

