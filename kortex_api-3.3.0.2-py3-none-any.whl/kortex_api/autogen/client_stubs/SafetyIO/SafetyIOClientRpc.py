
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from .... import  *
from ....internal.NotificationHandler import _NotificationCallback
from ....internal import BitMaskTools
from ...messages import SafetyIO_pb2 as SafetyIOPb  # NOQA
from ...messages import Common_pb2 as CommonPb  # NOQA



class SafetyIOFunctionUid(Enum):
    uidSetSafetyIOConfiguration = 0x2f0001
    uidSetAllSafetyIOConfiguration = 0x2f0002
    uidGetSafetyIOConfiguration = 0x2f0003
    uidGetAllSafetyIOConfiguration = 0x2f0004
    uidGetSafetyIOStatus = 0x2f0005
    uidOnNotificationSafetyIOChangeTopic = 0x2f0006
    uidUnsubscribe = 0x2f0007



class SafetyIOClient():
    
    serviceVersion = 1
    serviceId = 47

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a SafetyIOClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetSafetyIOConfiguration(self, safetyioconfiguration: SafetyIOPb.SafetyIOConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a safety io
        """
        reqPayload = safetyioconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyIOFunctionUid.uidSetSafetyIOConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetAllSafetyIOConfiguration(self, safetyioconfigurationlist: SafetyIOPb.SafetyIOConfigurationList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all safeties io
        """
        reqPayload = safetyioconfigurationlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyIOFunctionUid.uidSetAllSafetyIOConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetSafetyIOConfiguration(self, safetyioinfo: SafetyIOPb.SafetyIOInfo, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyIOPb.SafetyIOConfiguration :
        """
        Retrieves a safety io
        """
        reqPayload = safetyioinfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyIOFunctionUid.uidGetSafetyIOConfiguration, deviceId, self.namespace, options)

        ansPayload = SafetyIOPb.SafetyIOConfiguration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllSafetyIOConfiguration(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyIOPb.SafetyIOConfigurationList :
        """
        Retrieves all safeties io
        """


        future = self.router._send(None, self.serviceVersion, SafetyIOFunctionUid.uidGetAllSafetyIOConfiguration, deviceId, self.namespace, options)

        ansPayload = SafetyIOPb.SafetyIOConfigurationList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetSafetyIOStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyIOPb.SafetyIOChannelStatus :
        """
        Retrieves bitmask of safety functions status
        """


        future = self.router._send(None, self.serviceVersion, SafetyIOFunctionUid.uidGetSafetyIOStatus, deviceId, self.namespace, options)

        ansPayload = SafetyIOPb.SafetyIOChannelStatus()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationSafetyIOChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyIOFunctionUid.uidOnNotificationSafetyIOChangeTopic, deviceId, self.namespace, options)

        ansPayload = SafetyIOPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = SafetyIOPb.SafetyIOChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(SafetyIOFunctionUid.uidOnNotificationSafetyIOChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, SafetyIOFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

