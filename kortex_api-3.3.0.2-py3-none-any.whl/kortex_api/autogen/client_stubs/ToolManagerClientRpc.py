
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ToolManager_pb2 as ToolManagerPb  # NOQA
from ..messages import ToolPlugin_pb2 as ToolPluginPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ToolManagerFunctionUid(Enum):
    uidGetAllToolsInformation = 0x2b0001
    uidGetToolInformation = 0x2b0002
    uidGetActiveToolInformationList = 0x2b0003
    uidSelectActiveToolList = 0x2b0004
    uidCreateCustomTool = 0x2b0005
    uidDeleteCustomTool = 0x2b0006
    uidUpdateToolInformation = 0x2b0007
    uidOnNotificationActiveToolInformationChangedTopic = 0x2b0008
    uidOnNotificationToolInformationTopic = 0x2b0009
    uidUnsubscribe = 0x2b000a



class ToolManagerClient():
    
    serviceVersion = 1
    serviceId = 43

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ToolManagerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def GetAllToolsInformation(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolInformationList :
        """
        Gets information about all the tools
        """


        future = self.router._send(None, self.serviceVersion, ToolManagerFunctionUid.uidGetAllToolsInformation, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.ToolInformationList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetToolInformation(self, toolhandle: ToolPluginPb.ToolHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolInformation :
        """
        Gets information about one specific tool
        The handle.identifier of the tool needs to match the identifier from an existing one, or else an ERROR_DEVICE, ENTITY_NOT_FOUND exception is thrown.
        
        """
        reqPayload = toolhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidGetToolInformation, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.ToolInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetActiveToolInformationList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolInformationList :
        """
        Gets information about the active tool list
        """


        future = self.router._send(None, self.serviceVersion, ToolManagerFunctionUid.uidGetActiveToolInformationList, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.ToolInformationList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SelectActiveToolList(self, toolhandlelist: ToolPluginPb.ToolHandleList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the tools from the tool handle list to active. The last tool in the list is the one farthest from the robot flange.
        The arm must be powered on and in monitored stop, or be powered off, or else an error ERROR_DEVICE, WRONG_MODE is thrown.
        The identifiers of the tools in the list need to match the identifier from an existing one, or else an ERROR_DEVICE, ENTITY_NOT_FOUND exception is thrown.
        
        """
        reqPayload = toolhandlelist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidSelectActiveToolList, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def CreateCustomTool(self, toolinformation: ToolPluginPb.ToolInformation, deviceId: int = 0, options = RouterClientSendOptions()) -> ToolPluginPb.ToolHandle :
        """
        Creates a Custom Tool entry
        The tool_plugin_type must be TOOL_TYPE_CUSTOM, or else the error ERROR_DEVICE, INVALID_PARAM is thrown.
        The friendly name size must be between 1 and 25.
        The mass must be entered in Kilograms and its value must be between 0 and 9 kg.
        The range for the cartesian transform must be between -1 and 1 meters for the translation coordinates x, y and z, between -180 and 180 degrees for rotation values theta_x and theta_y and between 0 and 180 degrees for theta_z.
        The center of mass must be entered in meters and its value must be between -1 and 1.
        The inertia must be between 0 and 1 kgm² for the diagonal values Ixx, Iyy and Izz and between -1 and 1 kgm² for the cross values Ixy, Ixz and Iyz.
        
        """
        reqPayload = toolinformation.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidCreateCustomTool, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.ToolHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteCustomTool(self, toolhandle: ToolPluginPb.ToolHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Deletes a Custom Tool entry
        The tool to be deleted needs to exist, or else an error ERROR_DEVICE, ENTITY_NOT_FOUND is thrown.
        The tool must not be in the active tool list, or else an error ERROR_DEVICE, INVALID_PARAM is thrown.
        The tool must be a custom tool to be deleted, or else an error ERROR_DEVICE, INVALID_PARAM is thrown.
        
        """
        reqPayload = toolhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidDeleteCustomTool, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def UpdateToolInformation(self, toolinformation: ToolPluginPb.ToolInformation, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Updates a Tool's information
        Updates on the tool information need to follow the same rules as the ones mentioned in CreateCustomTool's description.
        The handle.identifier of the tool to be updated needs to match the identifier from an existing tool, or else an ENTITY_NOT_FOUND exception is thrown.
        
        """
        reqPayload = toolinformation.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidUpdateToolInformation, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationActiveToolInformationChangedTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidOnNotificationActiveToolInformationChangedTopic, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ToolManagerPb.ActiveToolNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ToolManagerFunctionUid.uidOnNotificationActiveToolInformationChangedTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationToolInformationTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidOnNotificationToolInformationTopic, deviceId, self.namespace, options)

        ansPayload = ToolManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ToolManagerPb.ToolNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ToolManagerFunctionUid.uidOnNotificationToolInformationTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ToolManagerFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

