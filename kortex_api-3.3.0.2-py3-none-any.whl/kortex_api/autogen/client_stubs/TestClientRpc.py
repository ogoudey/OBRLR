
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import Test_pb2 as TestPb  # NOQA
from ..messages import Frame_pb2 as ApiPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class TestFunctionUid(Enum):
    uidSetMockValidationStruct = 0xff00001
    uidTestParamAndReturn = 0xff00002
    uidTestParamOnly = 0xff00003
    uidTestReturnOnly = 0xff00004
    uidTestTimeout = 0xff00005
    uidOnNotificationTestNotif = 0xff00006
    uidTestNotifUnsubscribe = 0xff00007
    uidTestAsync = 0xff00008
    uidTestConcurrence = 0xff00009
    uidTestTriggerNotif = 0xff0000a
    uidTestNotImplemented = 0xff0000b
    uidServerError = 0xff0000c
    uidUnsubscribe = 0xff0001e
    uidOnNotificationSomethingChangeTopic = 0xff0001f
    uidTriggerSomethingChangeTopic = 0xff00020
    uidWait = 0xff00021
    uidThrow = 0xff00022
    uidDisconnect = 0xff00023
    uidForget = 0xff00024
    uidNotImplemented = 0xff00025
    uidDeprecated = 0xff00027
    uidDeprecatedWithMessage = 0xff00028
    uidTestPrivateMethod = 0xff00029
    uidTestPublicMethod = 0xff0002a
    uidTestNoPermission = 0xff0002b



class TestClient():
    
    serviceVersion = 1
    serviceId = 4080

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a TestClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetMockValidationStruct(self, validatestruct: TestPb.validateStruct, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        """
        reqPayload = validatestruct.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidSetMockValidationStruct, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestParamAndReturn(self, sendstruct: TestPb.SendStruct, deviceId: int = 0, options = RouterClientSendOptions()) -> TestPb.RcvStruct :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """
        reqPayload = sendstruct.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidTestParamAndReturn, deviceId, self.namespace, options)

        ansPayload = TestPb.RcvStruct()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def TestParamOnly(self, sendstruct: TestPb.SendStruct, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """
        reqPayload = sendstruct.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidTestParamOnly, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestReturnOnly(self, deviceId: int = 0, options = RouterClientSendOptions()) -> TestPb.RcvStruct :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestReturnOnly, deviceId, self.namespace, options)

        ansPayload = TestPb.RcvStruct()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def TestTimeout(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestTimeout, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationTestNotif(self, callback, notifoption: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notifoption.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidOnNotificationTestNotif, deviceId, self.namespace, options)

        ansPayload = TestPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = TestPb.TestNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(TestFunctionUid.uidOnNotificationTestNotif, self.namespace, notifCallback)
        return ansPayload

    def TestNotifUnsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        """
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidTestNotifUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def TestAsync(self, timetoresponse: TestPb.timeToResponse, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        rpc TestNotifUnsubscribe (Kinova.Api.Common.NotificationHandle) returns (Kinova.Api.Common.Empty);@RPC_ID=7 @PERMISSION=READ_ONLY @UNSUB @ACCESS_SCOPE=PUBLIC
        """
        reqPayload = timetoresponse.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidTestAsync, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestConcurrence(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        rpc TestNotifUnsubscribe (Kinova.Api.Common.NotificationHandle) returns (Kinova.Api.Common.Empty);@RPC_ID=7 @PERMISSION=READ_ONLY @UNSUB @ACCESS_SCOPE=PUBLIC
        rpc TestAsync (timeToResponse) returns (Kinova.Api.Common.Empty);@RPC_ID=8 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestConcurrence, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestTriggerNotif(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        rpc TestNotifUnsubscribe (Kinova.Api.Common.NotificationHandle) returns (Kinova.Api.Common.Empty);@RPC_ID=7 @PERMISSION=READ_ONLY @UNSUB @ACCESS_SCOPE=PUBLIC
        rpc TestAsync (timeToResponse) returns (Kinova.Api.Common.Empty);@RPC_ID=8 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestConcurrence (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=9 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestTriggerNotif, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestNotImplemented(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        rpc TestNotifUnsubscribe (Kinova.Api.Common.NotificationHandle) returns (Kinova.Api.Common.Empty);@RPC_ID=7 @PERMISSION=READ_ONLY @UNSUB @ACCESS_SCOPE=PUBLIC
        rpc TestAsync (timeToResponse) returns (Kinova.Api.Common.Empty);@RPC_ID=8 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestConcurrence (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=9 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTriggerNotif (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=10 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestNotImplemented, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ServerError(self, testerror: TestPb.TestError, deviceId: int = 0, options = RouterClientSendOptions()) -> TestPb.TestError :
        """
        rpc SetMockValidationStruct (validateStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=1 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamAndReturn (SendStruct) returns (RcvStruct);@RPC_ID=2 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestParamOnly (SendStruct) returns (Kinova.Api.Common.Empty);@RPC_ID=3 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestReturnOnly (Kinova.Api.Common.Empty) returns (RcvStruct);@RPC_ID=4 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTimeout (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=5 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotif (NotifOption) returns (Kinova.Api.Common.NotificationHandle);@RPC_ID=6 @PERMISSION=READ_ONLY @PUB_SUB=TestNotification @ACCESS_SCOPE=PUBLIC
        rpc TestNotifUnsubscribe (Kinova.Api.Common.NotificationHandle) returns (Kinova.Api.Common.Empty);@RPC_ID=7 @PERMISSION=READ_ONLY @UNSUB @ACCESS_SCOPE=PUBLIC
        rpc TestAsync (timeToResponse) returns (Kinova.Api.Common.Empty);@RPC_ID=8 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestConcurrence (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=9 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestTriggerNotif (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=10 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        rpc TestNotImplemented (Kinova.Api.Common.Empty) returns (Kinova.Api.Common.Empty);@RPC_ID=11 @PERMISSION=READ_ONLY @ACCESS_SCOPE=PUBLIC
        """
        reqPayload = testerror.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidServerError, deviceId, self.namespace, options)

        ansPayload = TestPb.TestError()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes from a given notification
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def OnNotificationSomethingChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidOnNotificationSomethingChangeTopic, deviceId, self.namespace, options)

        ansPayload = TestPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = TestPb.SomethingChanged()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(TestFunctionUid.uidOnNotificationSomethingChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def TriggerSomethingChangeTopic(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Triggers "SomethingChangeTopic" notification
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTriggerSomethingChangeTopic, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Wait(self, delay: TestPb.Delay, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Waits for a given time before reply
        """
        reqPayload = delay.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidWait, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Throw(self, error: ApiPb.Error, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Returns a given error
        """
        reqPayload = error.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidThrow, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Disconnect(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Server will close the current session (clean=false)
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidDisconnect, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Forget(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Server never replies
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidForget, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def NotImplemented(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Should return a "not implemented" error
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidNotImplemented, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    @deprecated
    def Deprecated(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Purposely deprecated method
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidDeprecated, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    @deprecated("Purposely deprecated for test")
    def DeprecatedWithMessage(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Purposely deprecated method (with message)
        """
        """
        Purposely deprecated method
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidDeprecatedWithMessage, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def TestPublicMethod(self, sendstruct: TestPb.SendStruct, deviceId: int = 0, options = RouterClientSendOptions()) -> TestPb.RcvStruct :
        """
        A public method for testing
        """
        reqPayload = sendstruct.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, TestFunctionUid.uidTestPublicMethod, deviceId, self.namespace, options)

        ansPayload = TestPb.RcvStruct()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def TestNoPermission(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        """


        future = self.router._send(None, self.serviceVersion, TestFunctionUid.uidTestNoPermission, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





