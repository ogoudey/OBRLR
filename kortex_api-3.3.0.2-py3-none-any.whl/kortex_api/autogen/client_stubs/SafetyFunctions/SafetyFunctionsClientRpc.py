
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from .... import  *
from ....internal.NotificationHandler import _NotificationCallback
from ....internal import BitMaskTools
from ...messages import SafetyFunctions_pb2 as SafetyFunctionsPb  # NOQA
from ...messages import Common_pb2 as CommonPb  # NOQA



class SafetyFunctionsFunctionUid(Enum):
    uidIsSupported = 0x290001
    uidSetJointPositionLimits = 0x290002
    uidSetAllJointPositionLimits = 0x290003
    uidGetJointPositionLimits = 0x290004
    uidGetAllJointPositionLimits = 0x290005
    uidSetJointSpeedLimit = 0x290006
    uidSetAllJointSpeedLimit = 0x290007
    uidGetJointSpeedLimit = 0x290008
    uidGetAllJointSpeedLimit = 0x290009
    uidUnsubscribe = 0x29000a
    uidOnNotificationSafetyFunctionChangeTopic = 0x29000b
    uidGetSafetyFunctionsStatus = 0x29000c
    uidSetTcpSpeedLimits = 0x29000d
    uidSetAllTcpSpeedLimits = 0x29000e
    uidGetTcpSpeedLimits = 0x29000f
    uidGetAllTcpSpeedLimits = 0x290010
    uidSetTcpForceLimit = 0x290011
    uidSetAllTcpForceLimit = 0x290012
    uidGetTcpForceLimit = 0x290013
    uidGetAllTcpForceLimit = 0x290014
    uidSetTcpOrientationLimits = 0x290015
    uidSetAllTcpOrientationLimits = 0x290016
    uidGetTcpOrientationLimits = 0x290017
    uidGetAllTcpOrientationLimits = 0x290018
    uidSetElbowSpeedLimit = 0x290019
    uidSetAllElbowSpeedLimit = 0x29001a
    uidGetElbowSpeedLimit = 0x29001b
    uidGetAllElbowSpeedLimit = 0x29001c
    uidSetElbowForceLimit = 0x29001d
    uidSetAllElbowForceLimit = 0x29001e
    uidGetElbowForceLimit = 0x29001f
    uidGetAllElbowForceLimit = 0x290020
    uidGetSafetyFunctionsLimitsRange = 0x290021
    uidGetSafetyFunctionsLimits = 0x290022
    uidGetSafetySystemMode = 0x290023
    uidSetSafetySystemMode = 0x290024
    uidOnNotificationSafetyModeChangeTopic = 0x290025
    uidGetProtectiveStopStatus = 0x290026
    uidOnNotificationProtectiveStopChangeTopic = 0x290027



class SafetyFunctionsClient():
    
    serviceVersion = 1
    serviceId = 41

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a SafetyFunctionsClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetJointPositionLimits(self, jointpositionlimits: SafetyFunctionsPb.JointPositionLimits, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a safety joint position limits
        """
        reqPayload = jointpositionlimits.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetJointPositionLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetAllJointPositionLimits(self, jointpositionlimitslist: SafetyFunctionsPb.JointPositionLimitsList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all safeties joint position limits for every safety system mode of each joint
        """
        reqPayload = jointpositionlimitslist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetAllJointPositionLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetJointPositionLimits(self, jointpositioninfo: SafetyFunctionsPb.JointPositionInfo, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.JointPositionLimits :
        """
        Retrieves a safety joint position limits for a specific identifier and safety mode
        """
        reqPayload = jointpositioninfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetJointPositionLimits, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.JointPositionLimits()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllJointPositionLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.JointPositionLimitsList :
        """
        Retrieves all safeties joint position limits for every safety system mode
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetAllJointPositionLimits, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.JointPositionLimitsList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetJointSpeedLimit(self, jointspeedlimit: SafetyFunctionsPb.JointSpeedLimit, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a safety joint speed limit
        """
        reqPayload = jointspeedlimit.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetJointSpeedLimit, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetAllJointSpeedLimit(self, jointspeedlimitlist: SafetyFunctionsPb.JointSpeedLimitList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all safeties joint speed limit for every safety system mode of each joint
        """
        reqPayload = jointspeedlimitlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetAllJointSpeedLimit, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetJointSpeedLimit(self, jointspeedinfo: SafetyFunctionsPb.JointSpeedInfo, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.JointSpeedLimit :
        """
        Retrieves a safety joint speed limit for a specific identifier and safety mode
        """
        reqPayload = jointspeedinfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetJointSpeedLimit, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.JointSpeedLimit()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllJointSpeedLimit(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.JointSpeedLimitList :
        """
        Retrieves all safeties joint speed limit for every safety system mode
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetAllJointSpeedLimit, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.JointSpeedLimitList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def OnNotificationSafetyFunctionChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidOnNotificationSafetyFunctionChangeTopic, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = SafetyFunctionsPb.SafetyFunctionChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(SafetyFunctionsFunctionUid.uidOnNotificationSafetyFunctionChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def GetSafetyFunctionsStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.SafetyFunctionsStatus :
        """
        Retrieves bitmask of safety functions status
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetSafetyFunctionsStatus, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.SafetyFunctionsStatus()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetTcpSpeedLimits(self, tcpspeedlimits: SafetyFunctionsPb.TcpSpeedLimits, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a safety tool center point speed limits
        """
        reqPayload = tcpspeedlimits.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetTcpSpeedLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetAllTcpSpeedLimits(self, tcpspeedlimitslist: SafetyFunctionsPb.TcpSpeedLimitsList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all safeties tool center point speed limits for each safety system mode
        """
        reqPayload = tcpspeedlimitslist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetAllTcpSpeedLimits, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetTcpSpeedLimits(self, tcpinfo: SafetyFunctionsPb.TcpInfo, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.TcpSpeedLimits :
        """
        Retrieves a safety tool center point speed limits for a specific safety mode
        """
        reqPayload = tcpinfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetTcpSpeedLimits, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.TcpSpeedLimits()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllTcpSpeedLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.TcpSpeedLimitsList :
        """
        Retrieves all safeties tool center point speed limits for all safety modes
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetAllTcpSpeedLimits, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.TcpSpeedLimitsList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetElbowSpeedLimit(self, elbowspeedlimit: SafetyFunctionsPb.ElbowSpeedLimit, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets a safety elbow speed limit
        """
        reqPayload = elbowspeedlimit.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetElbowSpeedLimit, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def SetAllElbowSpeedLimit(self, elbowspeedlimitlist: SafetyFunctionsPb.ElbowSpeedLimitList, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets all safeties elbow speed limit for each safety system mode
        """
        reqPayload = elbowspeedlimitlist.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetAllElbowSpeedLimit, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetElbowSpeedLimit(self, elbowinfo: SafetyFunctionsPb.ElbowInfo, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.ElbowSpeedLimit :
        """
        Retrieves a safety elbow speed limit for a specific safety mode
        """
        reqPayload = elbowinfo.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetElbowSpeedLimit, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.ElbowSpeedLimit()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetAllElbowSpeedLimit(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.ElbowSpeedLimitList :
        """
        Retrieves all safeties elbow speed limit for all safety modes
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetAllElbowSpeedLimit, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.ElbowSpeedLimitList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetSafetyFunctionsLimitsRange(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.SafetyFunctionsLimitsRange :
        """
        Retrieves all limits of all safety functions for each system safety mode
        """
        """
        Retrieves all limits admissible range of all safety functions for each system safety mode
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetSafetyFunctionsLimitsRange, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.SafetyFunctionsLimitsRange()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetSafetyFunctionsLimits(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.SafetyFunctionsLimits :
        """
        Retrieves all limits of all safety functions for each system safety mode
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetSafetyFunctionsLimits, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.SafetyFunctionsLimits()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetSafetySystemMode(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.SafetySystem :
        """
        Retrieves current safety system mode
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetSafetySystemMode, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.SafetySystem()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetSafetySystemMode(self, safetysystem: SafetyFunctionsPb.SafetySystem, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Sets the current safety mode
        """
        reqPayload = safetysystem.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidSetSafetySystemMode, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationSafetyModeChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidOnNotificationSafetyModeChangeTopic, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = SafetyFunctionsPb.SafetyModeChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(SafetyFunctionsFunctionUid.uidOnNotificationSafetyModeChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def GetProtectiveStopStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> SafetyFunctionsPb.ProtectiveStopStatus :
        """
        Retrieves current protective stop status
        """


        future = self.router._send(None, self.serviceVersion, SafetyFunctionsFunctionUid.uidGetProtectiveStopStatus, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.ProtectiveStopStatus()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationProtectiveStopChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, SafetyFunctionsFunctionUid.uidOnNotificationProtectiveStopChangeTopic, deviceId, self.namespace, options)

        ansPayload = SafetyFunctionsPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = SafetyFunctionsPb.ProtectiveStopChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(SafetyFunctionsFunctionUid.uidOnNotificationProtectiveStopChangeTopic, self.namespace, notifCallback)
        return ansPayload

