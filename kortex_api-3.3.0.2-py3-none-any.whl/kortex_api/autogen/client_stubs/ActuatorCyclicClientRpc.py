
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ActuatorCyclic_pb2 as ActuatorCyclicPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ActuatorCyclicFunctionUid(Enum):
    uidRefresh = 0xb0001
    uidRefreshCommand = 0xb0002
    uidRefreshFeedback = 0xb0003
    uidRefreshCustomData = 0xb0004
    uidRefreshCustom = 0xb0005



class ActuatorCyclicClient():
    
    serviceVersion = 1
    serviceId = 11

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ActuatorCyclicClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


