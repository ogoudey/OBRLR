
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import PluginManager_pb2 as PluginManagerPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class PluginManagerFunctionUid(Enum):
    uidInstallPlugin = 0x210001
    uidUpdatePlugin = 0x210002
    uidUninstallPlugin = 0x210003
    uidUninstallAllPlugins = 0x210004
    uidLaunchPlugin = 0x210005
    uidShutDownPlugin = 0x210006
    uidShutDownAllPlugins = 0x210007
    uidOnNotificationPluginUpdatedTopic = 0x210008
    uidOnNotificationPluginInstallationTopic = 0x210009
    uidUnsubscribe = 0x21000a
    uidGetPluginInfo = 0x21000b
    uidGetPluginsList = 0x21000c



class PluginManagerClient():
    
    serviceVersion = 1
    serviceId = 33

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a PluginManagerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def LaunchPlugin(self, pluginhandle: PluginManagerPb.PluginHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Launch an installed plugin
        """
        reqPayload = pluginhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidLaunchPlugin, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ShutDownPlugin(self, pluginhandle: PluginManagerPb.PluginHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Shut down a running plugin
        """
        reqPayload = pluginhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidShutDownPlugin, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ShutDownAllPlugins(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Shut down all running plugins
        """


        future = self.router._send(None, self.serviceVersion, PluginManagerFunctionUid.uidShutDownAllPlugins, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationPluginUpdatedTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidOnNotificationPluginUpdatedTopic, deviceId, self.namespace, options)

        ansPayload = PluginManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginManagerPb.PluginUpdatedNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginManagerFunctionUid.uidOnNotificationPluginUpdatedTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationPluginInstallationTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidOnNotificationPluginInstallationTopic, deviceId, self.namespace, options)

        ansPayload = PluginManagerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginManagerPb.PluginInstallationNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginManagerFunctionUid.uidOnNotificationPluginInstallationTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribe from PUB/SUB
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def GetPluginInfo(self, pluginhandle: PluginManagerPb.PluginHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginManagerPb.PluginInfo :
        """
        Get info for a specific plugin
        """
        reqPayload = pluginhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginManagerFunctionUid.uidGetPluginInfo, deviceId, self.namespace, options)

        ansPayload = PluginManagerPb.PluginInfo()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetPluginsList(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginManagerPb.PluginInfoList :
        """
        Get info of all plugins
        """


        future = self.router._send(None, self.serviceVersion, PluginManagerFunctionUid.uidGetPluginsList, deviceId, self.namespace, options)

        ansPayload = PluginManagerPb.PluginInfoList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

