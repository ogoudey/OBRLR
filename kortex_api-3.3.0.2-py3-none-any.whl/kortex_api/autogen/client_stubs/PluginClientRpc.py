
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import Plugin_pb2 as PluginPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class PluginFunctionUid(Enum):
    uidGetStatus = 0x1f0001
    uidSetUp = 0x1f0002
    uidTearDown = 0x1f0003
    uidStart = 0x1f0004
    uidStop = 0x1f0005
    uidGetMetaData = 0x1f0006
    uidGetConfiguration = 0x1f0007
    uidGetConfigurationSchema = 0x1f0008
    uidSetConfiguration = 0x1f0009
    uidResetConfiguration = 0x1f000a
    uidGetActionTypes = 0x1f000b
    uidStartAction = 0x1f000d
    uidPauseAction = 0x1f000e
    uidResumeAction = 0x1f000f
    uidStopAction = 0x1f0010
    uidOnNotificationStateTopic = 0x1f0011
    uidOnNotificationConfigurationChangeTopic = 0x1f0012
    uidOnNotificationActionTopic = 0x1f0013
    uidUnsubscribe = 0x1f0014
    uidGetVisualizers = 0x1f0016
    uidSetUpWithConfiguration = 0x1f0017
    uidTriggerUpdate = 0x1f0018
    uidSetUpAction = 0x1f001a
    uidTearDownAction = 0x1f001b
    uidOnNotificationInfoChangeTopic = 0x1f001c
    uidGetFeedback = 0x1f001d
    uidGetFeedbackSchema = 0x1f001e
    uidUpdateAction = 0x1f001f
    uidValidateAction = 0x1f0020
    uidMigrateAction = 0x1f0021



class PluginClient():
    
    serviceVersion = 1
    serviceId = 31

    def __init__(self, router: RouterClient, namespace: str):
        """Constructs a PluginClient with an initialized RouterClient and a namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def GetStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.Status :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetStatus, deviceId, self.namespace, options)

        ansPayload = PluginPb.Status()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetMetaData(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.MetaData :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetMetaData, deviceId, self.namespace, options)

        ansPayload = PluginPb.MetaData()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetConfiguration(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.Configuration :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetConfiguration, deviceId, self.namespace, options)

        ansPayload = PluginPb.Configuration()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetConfigurationSchema(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.ConfigurationSchema :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetConfigurationSchema, deviceId, self.namespace, options)

        ansPayload = PluginPb.ConfigurationSchema()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def SetConfiguration(self, configuration: PluginPb.Configuration, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = configuration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidSetConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ResetConfiguration(self, deviceId: int = 0, options = RouterClientSendOptions()) :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidResetConfiguration, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def GetActionTypes(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.ActionDescriptionList :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetActionTypes, deviceId, self.namespace, options)

        ansPayload = PluginPb.ActionDescriptionList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def StartAction(self, action: PluginPb.Action, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.ActionInstanceHandle :
        reqPayload = action.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidStartAction, deviceId, self.namespace, options)

        ansPayload = PluginPb.ActionInstanceHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def PauseAction(self, actioninstancehandle: PluginPb.ActionInstanceHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = actioninstancehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidPauseAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ResumeAction(self, actioninstancehandle: PluginPb.ActionInstanceHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = actioninstancehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidResumeAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def StopAction(self, actioninstancehandle: PluginPb.ActionInstanceHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = actioninstancehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidStopAction, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationStateTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidOnNotificationStateTopic, deviceId, self.namespace, options)

        ansPayload = PluginPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginPb.StateNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginFunctionUid.uidOnNotificationStateTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationConfigurationChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidOnNotificationConfigurationChangeTopic, deviceId, self.namespace, options)

        ansPayload = PluginPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginPb.ConfigurationChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginFunctionUid.uidOnNotificationConfigurationChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationActionTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidOnNotificationActionTopic, deviceId, self.namespace, options)

        ansPayload = PluginPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginPb.ActionNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginFunctionUid.uidOnNotificationActionTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def GetVisualizers(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.VisualizerList :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetVisualizers, deviceId, self.namespace, options)

        ansPayload = PluginPb.VisualizerList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def OnNotificationInfoChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, PluginFunctionUid.uidOnNotificationInfoChangeTopic, deviceId, self.namespace, options)

        ansPayload = PluginPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = PluginPb.InfoChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(PluginFunctionUid.uidOnNotificationInfoChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def GetFeedback(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.Feedback :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetFeedback, deviceId, self.namespace, options)

        ansPayload = PluginPb.Feedback()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetFeedbackSchema(self, deviceId: int = 0, options = RouterClientSendOptions()) -> PluginPb.FeedbackSchema :


        future = self.router._send(None, self.serviceVersion, PluginFunctionUid.uidGetFeedbackSchema, deviceId, self.namespace, options)

        ansPayload = PluginPb.FeedbackSchema()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

