
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ProgramRunner_pb2 as ProgramRunnerPb  # NOQA
from ..messages import ProgramConfig_pb2 as ProgramConfigPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ProgramRunnerFunctionUid(Enum):
    uidCreateProgram = 0x230001
    uidDeleteProgram = 0x230002
    uidReadAllPrograms = 0x230004
    uidReadProgram = 0x230005
    uidUpdateProgram = 0x230006
    uidExportProgram = 0x230007
    uidImportProgram = 0x230008
    uidGetStatus = 0x230009
    uidPause = 0x23000a
    uidResume = 0x23000b
    uidStart = 0x23000c
    uidStop = 0x23000d
    uidOnNotificationStateChangeTopic = 0x23000e
    uidOnNotificationStatusChangeTopic = 0x23000f
    uidOnNotificationConfigurationChangeTopic = 0x230010
    uidOnNotificationExecutionEventTopic = 0x230011
    uidUnsubscribe = 0x230012
    uidStartActions = 0x230013
    uidValidateProgram = 0x230014
    uidMigrateProgram = 0x230015
    uidMigrateAllPrograms = 0x230016
    uidGetLastBreakingChangeVersions = 0x230017



class ProgramRunnerClient():
    
    serviceVersion = 1
    serviceId = 35

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ProgramRunnerClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def CreateProgram(self, program: ProgramConfigPb.Program, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.ProgramHandle :
        """
        Create a program.
        
        If the program is not valid, an INVALID_PARAM error is thrown.
        
        """
        reqPayload = program.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidCreateProgram, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.ProgramHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def DeleteProgram(self, programhandle: CommonPb.ProgramHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Delete a program.
        
        If the program to delete is running, an ERROR_DEVICE error is thrown.
        
        """
        reqPayload = programhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidDeleteProgram, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ReadAllPrograms(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramConfigPb.ProgramList :
        """
        Read all programs
        """


        future = self.router._send(None, self.serviceVersion, ProgramRunnerFunctionUid.uidReadAllPrograms, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.ProgramList()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ReadProgram(self, programhandle: CommonPb.ProgramHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramConfigPb.Program :
        """
        Read a program.
        """
        reqPayload = programhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidReadProgram, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.Program()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def UpdateProgram(self, program: ProgramConfigPb.Program, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramConfigPb.Program :
        """
        Update an existing program.
        
        If the program is not valid, an INVALID_PARAM error is thrown.
        
        """
        reqPayload = program.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidUpdateProgram, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.Program()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ExportProgram(self, programhandle: CommonPb.ProgramHandle, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramConfigPb.ProgramJSON :
        """
        Export a program from Runner.
        """
        reqPayload = programhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidExportProgram, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.ProgramJSON()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def ImportProgram(self, programjson: ProgramConfigPb.ProgramJSON, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramRunnerPb.ImportProgramResult :
        """
        Import a program to Runner
        """
        reqPayload = programjson.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidImportProgram, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.ImportProgramResult()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def GetStatus(self, deviceId: int = 0, options = RouterClientSendOptions()) -> ProgramRunnerPb.StatusInformation :
        """
        Returns the current status.
        """


        future = self.router._send(None, self.serviceVersion, ProgramRunnerFunctionUid.uidGetStatus, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.StatusInformation()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)



        return ansPayload

    def Pause(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Pause an ongoing Program or Action.
        """


        future = self.router._send(None, self.serviceVersion, ProgramRunnerFunctionUid.uidPause, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Resume(self, runnablehandle: ProgramRunnerPb.RunnableHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Resume a paused Program or Action.
        The input argument RunnableHandle is unused, use a default RunnableHandle to make the call.
        
        If runner status is STATUS_PAUSED_AUTOMATIC_RESUME, an ERROR_DEVICE error is thrown.
        If the operating mode is different as it was when the program was started, an INVALID_PARAM error is thrown.
        
        """
        reqPayload = runnablehandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidResume, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Start(self, programstartconfiguration: ProgramRunnerPb.ProgramStartConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Start a program.
        
        An INVALID_PARAM error is thrown if any of the following occurs:
        - the program_handle is not set
        - the action_handle is set
        - the operating mode is not AUTO or HOLD_TO_RUN
        - the operating mode is AUTO, but the program is not validated
        - the program is not valid
        - the program is incompatible
        
        """
        reqPayload = programstartconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidStart, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def Stop(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Stop an ongoing Program or Action.
        
        If the status is neither paused nor running or if it is stopping or idle, an ERROR_DEVICE error is thrown.
        
        """


        future = self.router._send(None, self.serviceVersion, ProgramRunnerFunctionUid.uidStop, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def OnNotificationStateChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidOnNotificationStateChangeTopic, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProgramRunnerPb.StateChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProgramRunnerFunctionUid.uidOnNotificationStateChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationStatusChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidOnNotificationStatusChangeTopic, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProgramRunnerPb.StatusChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProgramRunnerFunctionUid.uidOnNotificationStatusChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationConfigurationChangeTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidOnNotificationConfigurationChangeTopic, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProgramConfigPb.ConfigurationChangeNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProgramRunnerFunctionUid.uidOnNotificationConfigurationChangeTopic, self.namespace, notifCallback)
        return ansPayload

    def OnNotificationExecutionEventTopic(self, callback, notificationoptions: CommonPb.NotificationOptions, deviceId: int = 0, options = RouterClientSendOptions()) -> CommonPb.NotificationHandle :
        reqPayload = notificationoptions.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidOnNotificationExecutionEventTopic, deviceId, self.namespace, options)

        ansPayload = ProgramRunnerPb.NotificationHandle()

        result = future.result(options.getTimeoutInSecond())

        ansPayload.ParseFromString(result.payload)

        def parseNotifDataFromString(payload):
            obj = ProgramRunnerPb.ExecutionEventNotification()
            obj.ParseFromString(payload)
            return obj

        notifCallback = _NotificationCallback(ansPayload.identifier, parseNotifDataFromString, callback)
        self.router._registerNotificationCallback(ProgramRunnerFunctionUid.uidOnNotificationExecutionEventTopic, self.namespace, notifCallback)
        return ansPayload

    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

    def StartActions(self, actionsstartconfiguration: ProgramRunnerPb.ActionsStartConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Start specified action of a program.
        
        An INVALID_PARAM error is thrown if any of the following occurs:
        - the program_handle is not set
        - the operating mode is not HOLD_TO_RUN
        - the parent program is not valid
        - the parent program of the action is incompatible
        
        """
        """
        Start a program.
        
        An INVALID_PARAM error is thrown if any of the following occurs:
        - the program_handle is not set
        - the action_handle is set
        - the operating mode is not AUTO or HOLD_TO_RUN
        - the operating mode is AUTO, but the program is not validated
        - the program is not valid
        - the program is incompatible
        
        """
        reqPayload = actionsstartconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidStartActions, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def ValidateProgram(self, programvalidationconfiguration: ProgramRunnerPb.ProgramValidationConfiguration, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Validate a program
        """
        reqPayload = programvalidationconfiguration.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidValidateProgram, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def MigrateProgram(self, programhandle: CommonPb.ProgramHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Migrate a program.
        
        If the migration of one or more action(s) fail, a METHOD_FAILED error is thrown.
        
        """
        reqPayload = programhandle.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, ProgramRunnerFunctionUid.uidMigrateProgram, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def MigrateAllPrograms(self, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Migrate all programs.
        
        If the migration of one or more program(s) fail, a METHOD_FAILED error is thrown.
        
        """


        future = self.router._send(None, self.serviceVersion, ProgramRunnerFunctionUid.uidMigrateAllPrograms, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





